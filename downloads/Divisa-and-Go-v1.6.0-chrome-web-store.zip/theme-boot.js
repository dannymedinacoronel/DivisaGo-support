// Se ejecuta antes de pintar: aplica el último tema (Acero por defecto) sin esperar a chrome.storage.
(() => {
  const colors = { pink: "#fff7f9", day: "#fffdf8", night: "#211b22", "man-day": "#f8fbff", "man-night": "#181e25" };
  let boot = {};
  try {
    boot = JSON.parse(localStorage.getItem("divisagoBoot") || "{}");
  } catch {}
  const theme = Object.hasOwn(colors, boot.theme) ? boot.theme : "man-day";
  const root = document.documentElement;
  root.dataset.theme = theme;
  if (boot.language) root.classList.add("has-language");
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.content = colors[theme];
})();
