let currentLanguage = "es";
// Intl.DisplayNames carga datos ICU y es lento de crear: una sola vez por idioma y solo cuando hace falta.
const displayNamesCache = new Map();
function displayNames(type) {
  const key = `${currentLanguage}|${type}`;
  let names = displayNamesCache.get(key);
  if (!names) {
    names = new Intl.DisplayNames([currentLanguage], { type });
    displayNamesCache.set(key, names);
  }
  return names;
}
const CURRENCY_API_URL = "https://api.frankfurter.dev/v2/rates?base=EUR";
let CURRENCIES = Object.keys(CURRENCY_REGIONS).map((code) => createCurrency(code));
const REFRESH_INTERVAL_MS = 24 * 60 * 60 * 1000;
const MAX_REFERENCE_AGE_MS = 10 * REFRESH_INTERVAL_MS;
const CURRENCY_REQUEST_TIMEOUT_MS = 15000;
const QUOTE_REFRESH_INTERVAL_MS = 30 * 60 * 1000;
const QUOTE_CACHE_TTL_MS = 30 * 60 * 1000;
// Una cotización antigua se conserva (marcada como desactualizada) en vez de dejar la tarjeta vacía.
const QUOTE_STALE_MAX_MS = 24 * 60 * 60 * 1000;
const QUOTE_BACKOFF_MS = 90 * 60 * 1000;
const QUOTE_CACHE_MAX_ENTRIES = 40;
const THIRD_PARTY_PROVIDERS = ["wise", "xe", "tradingview"];
const QUOTE_REQUEST_TIMEOUT_MS = 8000;
const QUOTE_PROVIDERS = ["ecb", "wise", "xe", "tradingview"];
const ECB_CURRENCY_API_URL = "https://data-api.ecb.europa.eu/service/data/EXR";

const amountInput = document.querySelector("#amount");

// Convierte lo que escribe o pega la persona en un número: "1,000,000", "1.000.000", "1 000 000",
// "1.234,56", "1,234.56", "0,5"... Con un solo separador y tres cifras detrás se entiende como miles.
function parseAmount(text) {
  // Comas altas (1'000'000), espacios finos y guiones bajos: separador de miles.
  // Comas y puntos de otros alfabetos (，． ، ٫ ·) se normalizan a "," y ".".
  let value = String(text ?? "")
    .replace(/[\s'‘’ʼʻ´`′ʹ_\u00a0\u202f\u2009\u066c]/g, "")
    .replace(/[\uff0c\u060c]/g, ",")
    .replace(/[\uff0e\u066b\u00b7]/g, ".");
  if (!/^(?:\d[\d.,]*|[.,]\d+)$/.test(value)) return NaN;
  const dots = (value.match(/\./g) || []).length;
  const commas = (value.match(/,/g) || []).length;
  if (dots && commas) {
    const decimal = value.lastIndexOf(".") > value.lastIndexOf(",") ? "." : ",";
    const thousands = decimal === "." ? "," : ".";
    value = value.split(thousands).join("").replace(decimal, ".");
  } else if (dots + commas > 0) {
    const separator = dots ? "." : ",";
    const parts = value.split(separator);
    if (parts.length > 2) {
      const last = parts.at(-1);
      value = last.length === 3 ? parts.join("") : `${parts.slice(0, -1).join("")}.${last}`;
    } else {
      const [integer, fraction] = parts;
      value = fraction.length === 3 && integer.length >= 1 && integer.length <= 3 && Number(integer) !== 0
        ? integer + fraction
        : `${integer || "0"}.${fraction}`;
    }
  }
  const number = Number(value);
  return Number.isFinite(number) ? number : NaN;
}

// Texto para escribir un número en el campo sin que se lea como miles ("1.234" -> "1.2340").
function amountText(value) {
  let text = String(Number(value.toPrecision(12)));
  if (/e/i.test(text)) text = value.toFixed(8).replace(/\.?0+$/, "");
  return /^\d{1,3}\.\d{3}$/.test(text) ? `${text}0` : text;
}

// Solo se permiten cifras y separadores; lo demás se descarta al escribir o pegar.
function sanitizeAmountField(input) {
  const clean = input.value.replace(/[^\d.,\s'‘’ʼʻ´`′ʹ_\u00a0\u202f\u2009\u066b\u066c\uff0c\uff0e\u060c\u00b7]/g, "");
  if (clean === input.value) return;
  const position = Math.max(0, (input.selectionStart ?? clean.length) - (input.value.length - clean.length));
  input.value = clean;
  input.setSelectionRange(position, position);
}
amountInput.addEventListener("input", () => sanitizeAmountField(amountInput));
const fromSelect = document.querySelector("#from-currency");
const toSelect = document.querySelector("#to-currency");
const fromFlag = document.querySelector("#from-flag");
const toFlag = document.querySelector("#to-flag");
const fromTrigger = document.querySelector("#from-trigger");
const toTrigger = document.querySelector("#to-trigger");
const fromLabel = document.querySelector("#from-label");
const toLabel = document.querySelector("#to-label");
const fromPicker = document.querySelector("#from-picker");
const toPicker = document.querySelector("#to-picker");
const fromSearch = document.querySelector("#from-search");
const toSearch = document.querySelector("#to-search");
const fromOptions = document.querySelector("#from-options");
const toOptions = document.querySelector("#to-options");
const fromFavorites = document.querySelector("#from-favorites");
const toFavorites = document.querySelector("#to-favorites");
const fromNoResults = document.querySelector("#from-no-results");
const toNoResults = document.querySelector("#to-no-results");
const resultElement = document.querySelector("#result");
const conversionSourceElement = document.querySelector("#conversion-source");
const copyResultButton = document.querySelector("#copy-result");
const copyLabel = document.querySelector("#copy-label");
const copyFeedback = document.querySelector("#copy-feedback");
const rateElement = document.querySelector("#rate");
const statusElement = document.querySelector("#status");
const updatedElement = document.querySelector("#updated-at");
const refreshButton = document.querySelector("#refresh");
const swapButton = document.querySelector("#swap");
const quotesStatus = document.querySelector("#quotes-status");
const quotesPair = document.querySelector("#quotes-pair");
const refreshQuotesButton = document.querySelector("#refresh-quotes");
const themeSelect = document.querySelector("#theme-select");
const languageOverlay = document.querySelector("#language-overlay");
const languageDialogSelect = document.querySelector("#language-dialog-select");
const languageSelect = document.querySelector("#language-select");
const languageContinueButton = document.querySelector("#language-continue");
const appShell = document.querySelector("#app-shell");
const storageFeedback = document.querySelector("#storage-feedback");
const LANGUAGE_STORAGE_KEY = "divisagoLanguage";
const FAVORITES_STORAGE_KEY = "divisagoFavoriteCurrencies";
const SESSION_STATE_STORAGE_KEY = "divisagoSessionState";
const RATES_CACHE_STORAGE_KEY = "divisagoRatesCache";
const PREMIUM_STORAGE_KEY = "divisagoPremium";
const QUOTE_CACHE_STORAGE_KEY = "divisagoQuoteCache";
const CRYPTO_CACHE_STORAGE_KEY = "divisagoCryptoCache";
const TUTORIAL_STORAGE_KEY = "divisagoTutorialDone";
const THEME_COLORS = {
  pink: "#fff7f9",
  day: "#fffdf8",
  night: "#211b22",
  "man-day": "#f8fbff",
  "man-night": "#181e25"
};
const MARGINS_STORAGE_KEY = "divisagoMargins";
const AD_DISMISSED_STORAGE_KEY = "divisagoAdDismissed";
const RATE_SOURCE_STORAGE_KEY = "divisagoRateSource";
const THEME_STORAGE_KEY = "divisagoTheme";
const METALS_PREFS_STORAGE_KEY = "divisagoMetals";
const METALS_CACHE_STORAGE_KEY = "divisagoMetalsCache";
const RATE_SOURCES = ["wise", "frankfurter", "xe", "tradingview"];
let rateSource = "wise";
let adDismissed = false;
const DEFAULT_MARGINS = [5, 10, 15, 20, 50];
const MARGINS_MIGRATION_KEY = "divisagoMarginsHas50";
const MAX_MARGINS = 12;
let calcMargins = [...DEFAULT_MARGINS];
let currentTab = "fx";
let lastDivisaTab = "fx";
let tutorialDone = false;
let premiumUser = false;
let catalogueSignature = "";
let sessionStarted = false;
let storageFailureActive = false;
let favoriteCurrencies = [];

// Tema e idioma también en localStorage: theme-boot.js los lee de forma síncrona antes de pintar.
function saveBoot(language) {
  try {
    const boot = JSON.parse(localStorage.getItem("divisagoBoot") || "{}");
    boot.theme = document.documentElement.dataset.theme;
    if (language) boot.language = language;
    localStorage.setItem("divisagoBoot", JSON.stringify(boot));
  } catch {}
}

function setTheme(theme, { persist = false } = {}) {
  if (!Object.hasOwn(THEME_COLORS, theme)) return;
  themeSelect.value = theme;
  document.documentElement.dataset.theme = theme;
  document.querySelector('meta[name="theme-color"]').content = THEME_COLORS[theme];
  saveBoot();
  if (persist) void persistPreference(THEME_STORAGE_KEY, theme);
}

function pageScroller() {
  const root = document.documentElement;
  return root.classList.contains("is-panel") || root.classList.contains("is-tab") ? document.scrollingElement : document.body;
}
const getPageScroll = () => pageScroller().scrollTop;
const setPageScroll = (top) => { pageScroller().scrollTop = top; };

function translate(key, values = {}) {
  const template = DIVISAGO_LOCALES[currentLanguage]?.[key] ?? DIVISAGO_LOCALES.es[key] ?? key;
  return template.replace(/\{(\w+)\}/g, (_, name) => String(values[name] ?? `{${name}}`));
}

function applyTranslations() {
  document.documentElement.lang = currentLanguage;
  document.title = `Divisa&Go — ${translate("introCopy")}`;

  for (const element of document.querySelectorAll("[data-i18n]")) {
    element.textContent = translate(element.dataset.i18n);
  }
  for (const element of document.querySelectorAll("[data-i18n-html]")) {
    element.innerHTML = translate(element.dataset.i18nHtml);
  }
  for (const element of document.querySelectorAll("[data-i18n-placeholder]")) {
    element.placeholder = translate(element.dataset.i18nPlaceholder);
  }
  for (const element of document.querySelectorAll("[data-i18n-aria-label]")) {
    element.setAttribute("aria-label", translate(element.dataset.i18nAriaLabel));
  }
  for (const element of document.querySelectorAll("[data-i18n-title]")) {
    element.title = translate(element.dataset.i18nTitle);
  }
  document.querySelector("#theme-select").setAttribute("aria-label", translate("themeLabel"));
  document.querySelector("#language-select").setAttribute("aria-label", translate("languageLabel"));
  document.querySelector("#language-dialog-select").setAttribute("aria-label", translate("languageLabel"));
  const themeOptions = themeSelect.options;
  themeOptions[0].textContent = translate("themePink");
  themeOptions[1].textContent = translate("themeDay");
  themeOptions[2].textContent = translate("themeNight");
  themeOptions[3].textContent = translate("themeManDay");
  themeOptions[4].textContent = translate("themeManNight");

  languageDialogSelect.value = currentLanguage;
  languageSelect.value = currentLanguage;
  if (storageFailureActive) storageFeedback.textContent = translate("storageFailure");
}

function setLanguage(language) {
  if (!Object.hasOwn(DIVISAGO_LOCALES, language) || currentLanguage === language) return;
  currentLanguage = language;
  applyTranslations();
  if (currencyPickers.length) rebuildCurrencyCatalogue();
  if (rates) {
    statusElement.textContent = translate(rateStatusKey);
    setUpdatedLabel(referenceDate, referenceFetchedAt);
    updateConversion();
    renderQuotes();
  } else {
    updateConversion();
    renderQuotes();
    if (rateStatusKey === "statusFailure") {
      updatedElement.textContent = translate("rateRequestFailed");
      updatedElement.title = rateErrorDetail;
    }
  }
  renderHistory();
  renderTutorialStep();
  if (typeof renderCrypto === "function" && !panelCrypto.hidden) renderCrypto();
  if (!adBanner.hidden) showAd(getValidAds(), adIndex - 1);
}

function getLocalStorageArea() {
  const storageArea = globalThis.chrome?.storage?.local;
  if (!storageArea) {
    throw new Error("Chrome storage is unavailable. Reload Divisa&Go from chrome://extensions.");
  }
  return storageArea;
}

function getSessionStorageArea() {
  const storageArea = globalThis.chrome?.storage?.session;
  if (!storageArea) {
    throw new Error("Chrome session storage is unavailable. Reload Divisa&Go from chrome://extensions.");
  }
  return storageArea;
}

function showStorageFailure(error) {
  console.error("No se pudieron guardar o leer las preferencias o el estado de sesión de Divisa&Go:", error);
  storageFailureActive = true;
  storageFeedback.textContent = translate("storageFailure");
  storageFeedback.hidden = false;
}

const viewId = Math.random().toString(36).slice(2);
const LIVE_CACHE_STORAGE_KEY = "divisagoLiveCache";
let cryptoFiatPending = "";

// Todo lo que el usuario tiene entre manos: al pasar de popup a ventana o panel se recupera tal cual.
function getSessionState() {
  return {
    source: viewId,
    savedAt: Date.now(),
    amount: amountInput.value,
    from: fromSelect.value,
    to: toSelect.value,
    theme: themeSelect.value,
    language: currentLanguage,
    tab: currentTab,
    crypto: {
      amount: cryptoAmount.value,
      fiat: cryptoFiat.value || cryptoFiatPending,
      inverted: cryptoInverted,
      selected: cryptoSelectedId
    },
    historyPeriod,
    calc: { open: currentTab === "calc", expression: calcExpression, fresh: calcFresh },
    scroll: Math.round(getPageScroll())
  };
}

async function persistSessionState() {
  try {
    await getSessionStorageArea().set({ [SESSION_STATE_STORAGE_KEY]: getSessionState() });
  } catch (error) {
    showStorageFailure(error);
  }
}

function restoreSessionState(state) {
  if (!state || typeof state !== "object") return;
  if (typeof state.amount === "string" && state.amount.length <= 100) {
    amountInput.value = state.amount;
  }
  if (
    typeof state.from === "string" &&
    [...fromSelect.options].some((option) => option.value === state.from)
  ) {
    fromSelect.value = state.from;
  }
  if (
    typeof state.to === "string" &&
    [...toSelect.options].some((option) => option.value === state.to)
  ) {
    toSelect.value = state.to;
  }
  if (Object.hasOwn(THEME_COLORS, state.theme)) setTheme(state.theme);
  updateCurrencyFlags();
  updateOptionSelection(fromOptions, fromSelect.value);
  updateOptionSelection(toOptions, toSelect.value);
}

async function loadPreferences(retried = false) {
  try {
    const sessionRead = getSessionStorageArea().get([SESSION_STATE_STORAGE_KEY, LIVE_CACHE_STORAGE_KEY]);
    sessionRead.catch(() => {});
    const preferences = await getLocalStorageArea().get([
      LANGUAGE_STORAGE_KEY,
      FAVORITES_STORAGE_KEY,
      RATES_CACHE_STORAGE_KEY,
      TUTORIAL_STORAGE_KEY,
      MARGINS_STORAGE_KEY,
      MARGINS_MIGRATION_KEY,
      AD_DISMISSED_STORAGE_KEY,
      RATE_SOURCE_STORAGE_KEY,
      THEME_STORAGE_KEY,
      METALS_PREFS_STORAGE_KEY,
      METALS_CACHE_STORAGE_KEY,
      PREMIUM_STORAGE_KEY,
      QUOTE_CACHE_STORAGE_KEY,
      CRYPTO_CACHE_STORAGE_KEY
    ]);
    // Almacenamiento vacío (p. ej. tras reinstalar): se intenta recuperar el espejo sincronizado.
    if (!retried && !preferences[LANGUAGE_STORAGE_KEY] && await divisagoBackup.restoreFromMirrorIfEmpty()) {
      return loadPreferences(true);
    }
    if (Object.hasOwn(THEME_COLORS, preferences[THEME_STORAGE_KEY])) setTheme(preferences[THEME_STORAGE_KEY]);
    premiumUser = preferences[PREMIUM_STORAGE_KEY] === true;
    adDismissed = preferences[AD_DISMISSED_STORAGE_KEY] === true;
    // "auto" (antiguo valor por defecto) pasa a Wise; "ecb" equivale a Frankfurter.
    const storedSource = preferences[RATE_SOURCE_STORAGE_KEY];
    rateSource = RATE_SOURCES.includes(storedSource) ? storedSource : storedSource === "ecb" ? "frankfurter" : "wise";
    tutorialDone = preferences[TUTORIAL_STORAGE_KEY] === true;
    const savedLanguage = preferences[LANGUAGE_STORAGE_KEY];
    if (Object.hasOwn(DIVISAGO_LOCALES, savedLanguage)) saveBoot(savedLanguage);
    else document.documentElement.classList.remove("has-language");
    favoriteCurrencies = Array.isArray(preferences[FAVORITES_STORAGE_KEY])
      ? [...new Set(preferences[FAVORITES_STORAGE_KEY].filter((code) =>
        typeof code === "string" && /^[A-Z]{3}$/.test(code)
      ))]
      : [];
    renderCurrencyPickers();
    if (Array.isArray(preferences[MARGINS_STORAGE_KEY])) {
      calcMargins = normalizeMargins(preferences[MARGINS_STORAGE_KEY]);
      // Una sola vez: quien ya tenía una lista guardada recibe también el +50 %.
      if (preferences[MARGINS_MIGRATION_KEY] !== true) {
        calcMargins = normalizeMargins([...calcMargins, 50]);
        void persistPreference(MARGINS_STORAGE_KEY, calcMargins);
      }
    }
    if (preferences[MARGINS_MIGRATION_KEY] !== true) void persistPreference(MARGINS_MIGRATION_KEY, true);
    renderMargins();

    let sessionState;
    let liveCache;
    try {
      const savedState = await sessionRead;
      sessionState = savedState[SESSION_STATE_STORAGE_KEY];
      liveCache = savedState[LIVE_CACHE_STORAGE_KEY];
    } catch (error) {
      showStorageFailure(error);
    }
    restoreSessionState(sessionState);

    const activeLanguage = Object.hasOwn(DIVISAGO_LOCALES, sessionState?.language)
      ? sessionState.language
      : savedLanguage;
    if (Object.hasOwn(DIVISAGO_LOCALES, activeLanguage)) {
      setLanguage(activeLanguage);
    }
    applyCachedRates(preferences[RATES_CACHE_STORAGE_KEY]);
    applyCachedQuotes(preferences[QUOTE_CACHE_STORAGE_KEY]);
    applyCachedCrypto(preferences[CRYPTO_CACHE_STORAGE_KEY]);
    applyMetalsPreferences(preferences[METALS_PREFS_STORAGE_KEY], preferences[METALS_CACHE_STORAGE_KEY]);
    applyLiveCache(liveCache);
    restoreViewState(sessionState);
    if (Object.hasOwn(DIVISAGO_LOCALES, savedLanguage)) {
      languageOverlay.hidden = true;
      startSession(false);
    }
  } catch (error) {
    showStorageFailure(error);
  }
}

async function persistPreference(key, value) {
  try {
    await getLocalStorageArea().set({ [key]: value });
    storageFailureActive = false;
    storageFeedback.hidden = true;
    return true;
  } catch (error) {
    showStorageFailure(error);
    return false;
  }
}

async function startSession(persistLanguage = true) {
  if (sessionStarted) return;
  sessionStarted = true;
  const selectedLanguage = languageDialogSelect.value;
  setLanguage(selectedLanguage);
  languageOverlay.hidden = true;
  appShell.inert = !tutorialOverlay.hidden;
  if (!calcExpression) {
    const current = parseAmount(amountInput.value);
    if (Number.isFinite(current)) {
      calcExpression = String(current);
      calcFresh = true;
      renderCalculator();
    }
  }
  if (currentTab === "calc") calcExpressionElement.focus({ preventScroll: true });
  initialize();
  window.setInterval(() => {
    if (!document.hidden) void refreshQuotes({ includeThirdParty: true });
  }, QUOTE_REFRESH_INTERVAL_MS);
  if (!tutorialDone) openTutorial();
  // Copia diaria y anuncio esperan a que la primera pantalla esté pintada.
  window.setTimeout(() => {
    void divisagoBackup.snapshot("daily").then(() => renderAutoBackups());
    startAdBanner();
  }, 1500);
  if (persistLanguage) {
    void persistPreference(LANGUAGE_STORAGE_KEY, selectedLanguage);
    saveBoot(selectedLanguage);
  }
  void persistSessionState();
  window.setInterval(refreshRates, 60 * 60 * 1000);
}

let rates = null;
let refreshInProgress = false;
let primarySourceUnavailable = false;
let rateStatusKey = "marketTitle";
let rateErrorDetail = "";
let referenceFetchedAt = Date.now();
let nextRefreshAt = 0;
let referenceDate = "";
let copyableResult = null;
let quoteRequestSequence = 0;
let quoteRefreshTimeout = 0;
let quoteAbortController = null;
let quoteRefreshPending = false;
let lastQuoteCheck = 0;
let lastQuoteSuccesses = null;
const quoteCache = new Map();
const quoteBackoffUntil = {};
const quoteFetching = {};

function getQuote(provider, source, target) {
  return quoteCache.get(`${provider}:${source}>${target}`) || null;
}

function storeQuote(provider, quote) {
  const key = `${provider}:${quote.source}>${quote.target}`;
  quoteCache.delete(key);
  quoteCache.set(key, quote);
  while (quoteCache.size > QUOTE_CACHE_MAX_ENTRIES) {
    quoteCache.delete(quoteCache.keys().next().value);
  }
  scheduleQuoteCachePersist();
}

let quoteCachePersistTimeout = 0;

// La caché sobrevive al cierre del popup, pero solo mientras la cotización siga siendo reciente.
function scheduleQuoteCachePersist() {
  window.clearTimeout(quoteCachePersistTimeout);
  quoteCachePersistTimeout = window.setTimeout(() => {
    const now = Date.now();
    const entries = [...quoteCache].filter(([, quote]) => now - quote.fetchedAt < QUOTE_STALE_MAX_MS);
    void persistPreference(QUOTE_CACHE_STORAGE_KEY, entries);
  }, 1000);
}

function applyCachedQuotes(entries) {
  if (!Array.isArray(entries)) return;
  const now = Date.now();
  for (const entry of entries) {
    if (!Array.isArray(entry) || entry.length !== 2) continue;
    const [key, quote] = entry;
    if (
      typeof key !== "string" ||
      !/^(ecb|wise|xe|tradingview):[A-Z]{3}>[A-Z]{3}$/.test(key) ||
      !quote || typeof quote !== "object" ||
      !Number.isFinite(quote.rate) || quote.rate <= 0 ||
      !Number.isFinite(quote.fetchedAt) ||
      now - quote.fetchedAt >= QUOTE_STALE_MAX_MS || quote.fetchedAt > now ||
      key.slice(key.indexOf(":") + 1) !== `${quote.source}>${quote.target}`
    ) continue;
    quoteCache.set(key, {
      rate: quote.rate,
      fetchedAt: quote.fetchedAt,
      source: quote.source,
      target: quote.target,
      referenceDate: typeof quote.referenceDate === "string" ? quote.referenceDate : undefined,
      providerTimestamp: typeof quote.providerTimestamp === "string" ? quote.providerTimestamp : ""
    });
  }
  renderQuotes();
  updateConversion();
}
const quoteErrors = Object.fromEntries(QUOTE_PROVIDERS.map((provider) => [provider, ""]));
const currencyPickers = [];

function populateCurrencySelect(select) {
  const fragment = document.createDocumentFragment();
  for (const currency of CURRENCIES) {
    const option = document.createElement("option");
    option.value = currency.code;
    option.textContent = `${currency.country} · ${currency.code}`;
    fragment.append(option);
  }
  select.append(fragment);
}

function createCurrency(code, sourceName = "") {
  const region = CURRENCY_REGIONS[code];
  const country = region ? displayNames("region").of(region) : sourceName || code;
  const localizedName = displayNames("currency").of(code);
  const name = localizedName && localizedName !== code ? localizedName : sourceName || code;
  const flag = region
    ? String.fromCodePoint(...Array.from(region, (character) => 0x1f1e6 + character.charCodeAt(0) - 65))
    : "🌐";
  const normalize = (value) => value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase(currentLanguage);

  return {
    code,
    country,
    name,
    flag,
    searchText: normalize(`${code} ${country} ${name} ${sourceName}`)
  };
}

function flagAssetPath(flag) {
  const regionalIndicators = Array.from(flag)
    .map((character) => character.codePointAt(0).toString(16));
  if (regionalIndicators.length !== 2 || regionalIndicators.some((point) => !/^[0-9a-f]{5}$/.test(point))) {
    return null;
  }
  return `icons/flags/${regionalIndicators.join("-")}.svg`;
}

function createFlagElement(flag, className) {
  const path = flagAssetPath(flag);
  if (!path) {
    const fallback = document.createElement("span");
    fallback.className = className;
    fallback.textContent = flag;
    fallback.setAttribute("aria-hidden", "true");
    return fallback;
  }
  const image = document.createElement("img");
  image.className = className;
  image.loading = "lazy";
  image.decoding = "async";
  image.src = path;
  image.alt = "";
  image.setAttribute("aria-hidden", "true");
  image.addEventListener("error", () => {
    const fallback = document.createElement("span");
    fallback.className = className;
    fallback.textContent = flag;
    fallback.setAttribute("aria-hidden", "true");
    image.replaceWith(fallback);
  }, { once: true });
  return image;
}

function renderCurrencyOptions(select, optionsElement, favoritesElement, onSelect) {
  const fragment = document.createDocumentFragment();
  for (const currency of CURRENCIES) {
    const row = document.createElement("div");
    row.className = "currency-option-row";
    row.dataset.search = currency.searchText;
    const option = document.createElement("button");
    option.className = "currency-option";
    option.type = "button";
    option.setAttribute("role", "option");
    option.setAttribute("aria-selected", String(select.value === currency.code));
    option.dataset.value = currency.code;
    option.dataset.search = currency.searchText;
    option.append(createFlagElement(currency.flag, "currency-option-flag"));

    const copy = document.createElement("span");
    copy.className = "currency-option-copy";
    const country = document.createElement("span");
    country.className = "currency-option-country";
    country.textContent = currency.country;
    const name = document.createElement("span");
    name.className = "currency-option-name";
    name.textContent = currency.name;
    copy.append(country, name);
    option.append(copy);

    const currencyCode = document.createElement("span");
    currencyCode.className = "currency-option-code";
    currencyCode.textContent = currency.code;
    option.append(currencyCode);

    const availability = document.createElement("span");
    availability.className = "currency-option-status";
    option.append(availability);
    row.append(option);

    const favoriteButton = document.createElement("button");
    favoriteButton.className = "currency-favorite-toggle";
    favoriteButton.type = "button";
    favoriteButton.dataset.currency = currency.code;
    favoriteButton.addEventListener("click", () => toggleCurrencyFavorite(currency.code));
    row.append(favoriteButton);
    option.addEventListener("click", () => onSelect(currency.code));
    fragment.append(row);
  }
  optionsElement.replaceChildren(fragment);
  renderFavoriteShortcuts(favoritesElement, onSelect);
}

function renderFavoriteShortcuts(favoritesElement, onSelect) {
  const favoriteFragment = document.createDocumentFragment();
  for (const code of favoriteCurrencies) {
    const currency = CURRENCIES.find((item) => item.code === code);
    if (!currency) continue;
    const favoriteButton = document.createElement("button");
    favoriteButton.className = "currency-favorite-shortcut";
    favoriteButton.type = "button";
    favoriteButton.dataset.value = currency.code;
    favoriteButton.dataset.search = currency.searchText;
    favoriteButton.setAttribute("aria-label", `${currency.country} · ${currency.code}`);
    favoriteButton.append(createFlagElement(currency.flag, "currency-option-flag"));
    const codeLabel = document.createElement("span");
    codeLabel.textContent = currency.code;
    favoriteButton.append(codeLabel);
    favoriteButton.addEventListener("click", () => onSelect(currency.code));
    favoriteFragment.append(favoriteButton);
  }
  favoritesElement.replaceChildren(favoriteFragment);
}

function updateCurrencyFavoriteButtons() {
  for (const button of document.querySelectorAll(".currency-favorite-toggle")) {
    const currency = CURRENCIES.find(({ code }) => code === button.dataset.currency);
    const isFavorite = favoriteCurrencies.includes(button.dataset.currency);
    const label = currency
      ? `${currency.country} · ${currency.code}`
      : button.dataset.currency;
    button.textContent = isFavorite ? "★" : "☆";
    button.setAttribute("aria-label", translate(isFavorite ? "favoriteRemove" : "favoriteAdd", {
      currency: label
    }));
    button.title = translate(isFavorite ? "favoriteRemove" : "favoriteAdd", {
      currency: label
    });
    button.setAttribute("aria-pressed", String(isFavorite));
  }
  for (const picker of currencyPickers) {
    picker.favoritesSection.hidden = picker.favoritesElement.childElementCount === 0;
  }
}

function renderCurrencyPickers() {
  for (const picker of currencyPickers) {
    picker.render();
    updateCurrencyAvailability(picker.optionsElement);
    updateOptionSelection(picker.optionsElement, picker.select.value);
    picker.searchInput.dispatchEvent(new Event("input"));
  }
  updateCurrencyFavoriteButtons();
}

async function toggleCurrencyFavorite(code) {
  const previousFavorites = favoriteCurrencies;
  favoriteCurrencies = previousFavorites.includes(code)
    ? previousFavorites.filter((favorite) => favorite !== code)
    : [...previousFavorites, code];
  refreshFavoriteViews();
  const saved = await persistPreference(FAVORITES_STORAGE_KEY, favoriteCurrencies);
  if (!saved) {
    favoriteCurrencies = previousFavorites;
    refreshFavoriteViews();
  }
}

// Actualiza solo estrellas y accesos rápidos, sin reconstruir las listas ni perder la posición del scroll.
function refreshFavoriteViews() {
  for (const picker of currencyPickers) {
    if (!picker.dirty) {
      picker.renderFavorites();
      updateCurrencyAvailability(picker.optionsElement);
      picker.searchInput.dispatchEvent(new Event("input"));
    }
  }
  updateCurrencyFavoriteButtons();
}

function updateCurrencyPicker(select, flagElement, labelElement, trigger) {
  const currency = CURRENCIES.find(({ code }) => code === select.value);
  flagElement.replaceChildren();
  if (!currency) {
    labelElement.textContent = "";
    return;
  }
  flagElement.append(createFlagElement(currency.flag, "currency-flag-image"));
  labelElement.textContent = `${currency.country} · ${currency.code}`;
  trigger.setAttribute("aria-label", `${currency.country}, ${currency.name}, ${currency.code}`);
}

function getQuoteUrl(provider, source, target) {
  switch (provider) {
    case "wise": {
      const url = new URL(
        `/gb/currency-converter/${source.toLowerCase()}-to-${target.toLowerCase()}-rate`,
        "https://wise.com"
      );
      url.searchParams.set("amount", "1");
      return url.href;
    }
    case "xe": {
      const url = new URL("/currencyconverter/convert/", "https://www.xe.com");
      url.searchParams.set("Amount", "1");
      url.searchParams.set("From", source);
      url.searchParams.set("To", target);
      return url.href;
    }
    case "tradingview":
      return `https://www.tradingview.com/symbols/${source}${target}/`;
    case "ecb":
      return "https://www.ecb.europa.eu/stats/policy_and_exchange_rates/euro_reference_exchange_rates/html/index.en.html";
    default:
      throw new Error(`Proveedor de cotización desconocido: ${provider}`);
  }
}

function getEcbCurrencyUrl(currency) {
  const url = new URL(
    `/service/data/EXR/D.${currency}.EUR.SP00.A`,
    ECB_CURRENCY_API_URL
  );
  url.searchParams.set("lastNObservations", "1");
  url.searchParams.set("format", "csvdata");
  return url.href;
}

function updateCurrencyFlags() {
  updateCurrencyPicker(fromSelect, fromFlag, fromLabel, fromTrigger);
  updateCurrencyPicker(toSelect, toFlag, toLabel, toTrigger);
  updateQuoteLinks();
}

function updateQuoteLinks() {
  for (const provider of QUOTE_PROVIDERS) {
    document.querySelector(`#quote-${provider}`).href = getQuoteUrl(provider, fromSelect.value, toSelect.value);
  }
  quotesPair.textContent = `${fromSelect.value} → ${toSelect.value}`;
}

function parseDisplayedRate(value) {
  const normalized = value.replace(/\s/g, "");
  const lastDot = normalized.lastIndexOf(".");
  const lastComma = normalized.lastIndexOf(",");
  if (lastDot === -1 && lastComma === -1) return Number(normalized);
  if (lastDot === -1 && /^\d{1,3},\d{3}$/.test(normalized) && !normalized.startsWith("0,")) {
    return Number(normalized.replace(",", ""));
  }
  const decimalSeparator = Math.max(lastDot, lastComma);
  const integer = normalized.slice(0, decimalSeparator).replace(/[.,]/g, "");
  const fraction = normalized.slice(decimalSeparator + 1).replace(/[.,]/g, "");
  return Number(`${integer}.${fraction}`);
}

function htmlToText(html) {
  return html
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;|&#160;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">");
}

function extractTradingViewJsonRate(html, target) {
  if (!html.includes(`"currency_code":"${target}"`)) return NaN;
  const match = html.match(/"trade":\{"price":([0-9.]+(?:[eE][+-]?\d+)?)\}/);
  return match ? Number(match[1]) : NaN;
}

function extractUnitRate(html, provider, source, target) {
  const text = htmlToText(html);
  const pair = `${source}\\s*=\\s*${target}`;
  const ratePattern = new RegExp(`\\b1(?:[.,]0+)?\\s+${source}\\s*=\\s*([\\d.,]+)\\s+${target}\\b`, "i");
  const tradingViewPattern = new RegExp(
    `\\bcurrent rate of ${source}${target} is\\s*([\\d.,]+)\\s+${target}\\b`,
    "i"
  );
  const match = provider === "tradingview"
    ? text.match(tradingViewPattern)
    : text.match(ratePattern);
  let value = match ? parseDisplayedRate(match[1]) : NaN;
  // En cruces poco habituales TradingView no escribe la frase, pero sí deja el precio en su JSON.
  if (!Number.isFinite(value) && provider === "tradingview") value = extractTradingViewJsonRate(html, target);
  if (!Number.isFinite(value) || value <= 0) {
    throw new Error(`No se encontró una tasa ${pair} válida en ${provider}.`);
  }
  return value;
}

function extractXeTimestamp(html) {
  const match = htmlToText(html).match(/Mid-market rate at\s+(\d{1,2}:\d{2}\s+UTC)/i);
  return match ? `${translate("providerData")}: ${match[1]}` : "";
}

// Lee la página por trozos y cancela la descarga en cuanto aparece la tasa, para no bajar la página completa.
async function readUntilQuoteFound(response, provider, source, target) {
  if (!response.body) {
    const html = await response.text();
    if (html.length > 1_500_000) {
      throw new Error(`La página de ${provider} es demasiado grande para leerla.`);
    }
    return html;
  }
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let html = "";
  let lastChecked = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (value) html += decoder.decode(value, { stream: true });
      if (html.length > 1_500_000) {
        throw new Error(`La página de ${provider} es demasiado grande para leerla.`);
      }
      if (done) return html;
      if (html.length - lastChecked >= 65536) {
        lastChecked = html.length;
        try {
          extractUnitRate(html, provider, source, target);
          if (provider !== "xe" || extractXeTimestamp(html)) return html;
        } catch {
          // La tasa todavía no ha llegado; se sigue leyendo.
        }
      }
    }
  } finally {
    reader.cancel().catch(() => {});
  }
}

const WISE_HISTORY_URL = "https://wise.com/rates/history";
const WISE_RANGES = { "1W": [7, "day"], "1M": [30, "day"], "3M": [3, "month"], "6M": [6, "month"], "1Y": [1, "year"], "5Y": [5, "year"] };

// Serie diaria u horaria de Wise (JSON público): más ligera y estable que leer su página web.
async function fetchWiseSeries(source, target, length, unit, resolution, signal) {
  const url = new URL(WISE_HISTORY_URL);
  url.searchParams.set("source", source);
  url.searchParams.set("target", target);
  url.searchParams.set("length", String(length));
  url.searchParams.set("resolution", resolution);
  url.searchParams.set("unit", unit);
  const response = await fetch(url, { cache: "no-store", credentials: "omit", signal });
  if (!response.ok) throw new Error(`Wise respondió con el código ${response.status}.`);
  const rows = await response.json();
  const points = (Array.isArray(rows) ? rows : [])
    .filter((row) => row && row.source === source && row.target === target &&
      Number.isFinite(row.value) && row.value > 0 && Number.isFinite(row.time))
    .map((row) => ({ time: row.time, rate: row.value }))
    .sort((a, b) => a.time - b.time);
  if (points.length === 0) throw new Error(`Wise no devolvió datos para ${source}/${target}.`);
  return points;
}

async function fetchWiseJsonQuote(source, target, signal) {
  const points = await fetchWiseSeries(source, target, 1, "day", "hourly", signal);
  const last = points.at(-1);
  if (Date.now() - last.time > 36 * 3600 * 1000) throw new Error("El último dato de Wise es demasiado antiguo.");
  return {
    rate: last.rate,
    providerTimestamp: `${translate("providerData")}: ${new Date(last.time).toISOString().slice(11, 16)} UTC`,
    fetchedAt: Date.now(),
    source,
    target
  };
}

function referenceRate(source, target) {
  const fromRate = rates && (source === "EUR" ? 1 : rates[source]?.rate);
  const toRate = rates && (target === "EUR" ? 1 : rates[target]?.rate);
  return Number.isFinite(fromRate) && Number.isFinite(toRate) ? toRate / fromRate : null;
}

// Una tasa que se aleja más de un 30 % de la referencia es casi seguro un error de lectura: se descarta.
function assertPlausible(rate, source, target) {
  const reference = referenceRate(source, target);
  if (reference && (rate / reference > 1.3 || rate / reference < 1 / 1.3)) {
    throw new Error(translate("quoteOutlier"));
  }
}

async function withRetry(task, signal) {
  try {
    return await task();
  } catch (error) {
    if (signal?.aborted) throw error;
    await new Promise((resolve) => window.setTimeout(resolve, 1200));
    if (signal?.aborted) throw error;
    return task();
  }
}

async function fetchQuote(provider, source, target, signal) {
  if (provider === "ecb") return fetchEcbQuote(source, target, signal);
  const quote = await withRetry(() => fetchThirdPartyQuote(provider, source, target, signal), signal);
  assertPlausible(quote.rate, source, target);
  return quote;
}

async function fetchThirdPartyQuote(provider, source, target, signal) {
  if (provider === "wise") {
    try {
      return await fetchWiseJsonQuote(source, target, signal);
    } catch (error) {
      if (signal?.aborted) throw error;
      console.warn("Wise (JSON) no disponible, se lee su página:", error);
    }
  }
  const response = await fetch(getQuoteUrl(provider, source, target), {
    cache: "no-store",
    credentials: "omit",
    signal
  });
  if (!response.ok) {
    throw new Error(`${provider} respondió con el código ${response.status}.`);
  }

  const html = await readUntilQuoteFound(response, provider, source, target);
  return {
    rate: extractUnitRate(html, provider, source, target),
    providerTimestamp: provider === "xe" ? extractXeTimestamp(html) : "",
    fetchedAt: Date.now(),
    source,
    target
  };
}

async function fetchEcbCurrencyRate(currency, signal) {
  if (currency === "EUR") return { rate: 1, date: "" };

  const response = await fetch(getEcbCurrencyUrl(currency), {
    cache: "no-store",
    credentials: "omit",
    signal
  });
  if (!response.ok) {
    throw new Error(`El BCE respondió con el código ${response.status}.`);
  }

  const csv = await response.text();
  const lines = csv.replace(/^\uFEFF/, "").trim().split(/\r?\n/);
  if (lines.length < 2) throw new Error(`El BCE no publica una tasa reciente para ${currency}.`);
  const headers = lines[0].split(",");
  const indexes = Object.fromEntries(
    ["CURRENCY", "CURRENCY_DENOM", "TIME_PERIOD", "OBS_VALUE"]
      .map((field) => [field, headers.indexOf(field)])
  );
  if (Object.values(indexes).some((index) => index < 0)) {
    throw new Error("La respuesta de tipos del BCE no tiene el formato esperado.");
  }

  for (const line of lines.slice(1).reverse()) {
    const fields = line.split(",");
    const date = fields[indexes.TIME_PERIOD];
    const rate = Number(fields[indexes.OBS_VALUE]);
    if (
      fields[indexes.CURRENCY] === currency &&
      fields[indexes.CURRENCY_DENOM] === "EUR" &&
      isRecentReferenceDate(date) &&
      Number.isFinite(rate) &&
      rate > 0
    ) {
      return { rate, date };
    }
  }
  throw new Error(`El BCE no publica una tasa reciente para ${currency}.`);
}

async function waitForReferenceRates(maxMs) {
  const deadline = Date.now() + maxMs;
  while (!rates && Date.now() < deadline) await new Promise((resolve) => window.setTimeout(resolve, 150));
}

async function fetchEcbQuote(source, target, signal) {
  try {
    return await fetchEcbDirectQuote(source, target, signal);
  } catch (error) {
    if (signal?.aborted) throw error;
    await waitForReferenceRates(5000);
    const rate = referenceRate(source, target);
    if (!rate) throw error;
    return {
      rate,
      referenceDate,
      fetchedAt: Date.now(),
      source,
      target,
      providerTimestamp: translate("quoteViaFrankfurter")
    };
  }
}

async function fetchEcbDirectQuote(source, target, signal) {
  if (source === target) {
    return {
      rate: 1,
      referenceDate: referenceDate,
      fetchedAt: Date.now(),
      source,
      target
    };
  }
  const [sourceReference, targetReference] = await Promise.all([
    fetchEcbCurrencyRate(source, signal),
    fetchEcbCurrencyRate(target, signal)
  ]);
  const rate = targetReference.rate / sourceReference.rate;
  if (!Number.isFinite(rate) || rate <= 0) {
    throw new Error("No se pudo calcular el tipo de referencia del BCE.");
  }
  const dates = [sourceReference.date, targetReference.date].filter(Boolean);
  const distinctDates = new Set(dates);
  return {
    rate,
    referenceDate: dates.sort().at(-1) || "",
    fetchedAt: Date.now(),
    source,
    target,
    providerTimestamp: distinctDates.size > 1
      ? translate("quoteDateMismatch")
      : ""
  };
}

function formatQuoteTime(quote) {
  if (quote.referenceDate) return translate("quoteDate", { date: formatReferenceDate(quote.referenceDate) });
  return translate("quoteChecked", { time: formatDateTime(quote.fetchedAt) });
}

function formatDateTime(timestamp) {
  return new Intl.DateTimeFormat(currentLanguage, {
    dateStyle: "medium",
    timeStyle: "short"
  }).format(new Date(timestamp));
}

function renderQuote(provider) {
  const quote = getQuote(provider, fromSelect.value, toSelect.value);
  const valueElement = document.querySelector(`#quote-${provider}-value`);
  const timeElement = document.querySelector(`#quote-${provider}-time`);
  const cardElement = document.querySelector(`#quote-${provider}`);
  const amount = parseAmount(amountInput.value);
  const isOld = quote && Date.now() - quote.fetchedAt > QUOTE_REFRESH_INTERVAL_MS * 2;

  cardElement.classList.toggle("is-stale", Boolean(quote && (quoteErrors[provider] || isOld)));
  if (!quote) {
    valueElement.textContent = quoteErrors[provider] ? translate("quoteUnavailable") : "—";
    timeElement.textContent = quoteErrors[provider]
      ? translate("quoteUnavailable")
      : translate(!quoteFetching[provider] && THIRD_PARTY_PROVIDERS.includes(provider) ? "quotePressRefresh" : "quoteLoading");
    timeElement.title = quoteErrors[provider];
    return;
  }

  if (amountInput.value.trim() === "" || !Number.isFinite(amount) || amount < 0) {
    valueElement.textContent = translate("quoteInvalid");
  } else if (amount === 0) {
    // Con cantidad 0 se enseña la tasa de 1 unidad en vez de un "0,00" que no dice nada.
    valueElement.textContent = translate("quoteUnitRate", { rate: formatRateValue(quote.rate), to: toSelect.value });
    valueElement.title = `1 ${fromSelect.value} = ${formatRateValue(quote.rate)} ${toSelect.value}`;
  } else {
    valueElement.textContent = formatAmount(amount * quote.rate, toSelect.value);
    valueElement.title = "";
  }
  timeElement.textContent = quoteErrors[provider] || isOld
    ? translate("quoteStale", { time: formatQuoteTime(quote) })
    : formatQuoteTime(quote);
  timeElement.title = [
    quoteErrors[provider],
    quote.providerTimestamp ? translate("quoteProviderTimestamp", { provider, time: quote.providerTimestamp }) : "",
    isOld ? translate("quoteStaleWarning") : ""
  ].filter(Boolean).join(" ");
}

function renderQuotes() {
  quotesPair.textContent = `${fromSelect.value} → ${toSelect.value}`;
  for (const provider of QUOTE_PROVIDERS) renderQuote(provider);
  renderQuoteStatus();
}

function getFallbackQuote(source, target) {
  const now = Date.now();
  return QUOTE_PROVIDERS
    .map((provider) => ({ provider, quote: getQuote(provider, source, target) }))
    .find(({ quote }) =>
      quote &&
      now - quote.fetchedAt <= QUOTE_REFRESH_INTERVAL_MS * 2
    ) || null;
}

function getQuoteProviderName(provider) {
  return {
    ecb: "BCE",
    wise: "Wise",
    xe: "Xe",
    tradingview: "TradingView"
  }[provider];
}

// ---- Fuente de la tasa elegida por el usuario ----
// "Frankfurter" es la referencia diaria del BCE que ya usa la app; internamente es el proveedor "ecb".
const providerOf = (source) => (source === "frankfurter" ? "ecb" : source);
const providerLabel = (provider) => (provider === "ecb" ? "Frankfurter" : getQuoteProviderName(provider));

function pickedQuote(from, to) {
  if (rateSource === "frankfurter" || from === to) return null;
  const quote = getQuote(rateSource, from, to);
  if (!quote || Date.now() - quote.fetchedAt > QUOTE_REFRESH_INTERVAL_MS * 2) return null;
  return { provider: rateSource, quote };
}

// Semáforo: compara las fuentes frescas del par y dice cuál da más a favor.
const LIGHT_TOLERANCE = 0.15; // % por debajo del cual se considera empate
const LIGHT_WARNING = 0.6; // % a partir del cual la diferencia ya es roja

function levelForGap(gap) {
  return gap <= LIGHT_TOLERANCE ? "green" : gap <= LIGHT_WARNING ? "amber" : "red";
}

function getRateLight(from, to) {
  if (from === to) return null;
  const now = Date.now();
  const entries = QUOTE_PROVIDERS
    .map((provider) => ({ provider, quote: getQuote(provider, from, to) }))
    .filter(({ quote }) => quote && now - quote.fetchedAt <= QUOTE_REFRESH_INTERVAL_MS * 2)
    .map(({ provider, quote }) => ({ provider, rate: quote.rate }));
  if (entries.length < 2) return null;
  const best = entries.reduce((top, entry) => (entry.rate > top.rate ? entry : top));
  const worst = entries.reduce((low, entry) => (entry.rate < low.rate ? entry : low));
  for (const entry of entries) {
    entry.gap = ((best.rate - entry.rate) / best.rate) * 100;
    entry.level = levelForGap(entry.gap);
  }
  const spread = ((best.rate - worst.rate) / best.rate) * 100;
  const activeProvider = providerOf(rateSource);
  const active = entries.find((entry) => entry.provider === activeProvider) ?? null;
  const percent = (value) => `${new Intl.NumberFormat(currentLanguage, { maximumFractionDigits: 2 }).format(value)}%`;
  let level;
  let text;
  if (spread <= LIGHT_TOLERANCE) {
    level = "green";
    text = translate("lightAgree", { spread: percent(spread) });
  } else if (!active) {
    level = "green";
    text = translate("lightBest", { source: providerLabel(best.provider) });
  } else if (active.gap <= LIGHT_TOLERANCE) {
    level = "green";
    text = active.provider === best.provider
      ? translate("lightBest", { source: providerLabel(best.provider) })
      : translate("lightNear", { active: providerLabel(active.provider) });
  } else {
    level = levelForGap(active.gap);
    text = translate("lightBetter", {
      best: providerLabel(best.provider),
      gap: percent(active.gap),
      active: providerLabel(active.provider)
    });
  }
  return { entries, level, text };
}

function renderSourcePickers() {
  const from = fromSelect.value;
  const to = toSelect.value;
  const now = Date.now();
  const availability = RATE_SOURCES.map((source) => {
    const quote = getQuote(providerOf(source), from, to);
    return quote && now - quote.fetchedAt <= QUOTE_REFRESH_INTERVAL_MS * 2 ? quote : null;
  });
  const light = getRateLight(from, to);
  const signature = [
    rateSource, from, to, currentLanguage,
    ...availability.map((quote) => quote?.rate ?? ""),
    light ? `${light.level}:${light.text}` : ""
  ].join("|");
  for (const picker of document.querySelectorAll(".source-picker")) {
    if (picker.dataset.signature === signature) continue;
    picker.dataset.signature = signature;
    picker.replaceChildren(...RATE_SOURCES.map((source, index) => {
      const button = document.createElement("button");
      button.type = "button";
      button.dataset.source = source;
      button.setAttribute("aria-pressed", String(rateSource === source));
      button.textContent = providerLabel(providerOf(source));
      const quote = availability[index];
      button.classList.toggle("has-rate", Boolean(quote));
      const entry = light?.entries.find((item) => item.provider === providerOf(source));
      for (const level of ["green", "amber", "red"]) button.classList.toggle(`level-${level}`, entry?.level === level);
      if (quote) {
        button.title = `1 ${from} = ${formatRateValue(quote.rate)} ${to}`;
        if (entry && entry.gap > 0) button.title += ` · −${new Intl.NumberFormat(currentLanguage, { maximumFractionDigits: 2 }).format(entry.gap)}%`;
      }
      return button;
    }));
    if (light) {
      const summary = document.createElement("span");
      summary.className = `rate-light is-${light.level}`;
      summary.textContent = light.text;
      summary.title = translate("lightTitle");
      picker.append(summary);
    }
  }
}

function setRateSource(source) {
  if (!RATE_SOURCES.includes(source)) return;
  rateSource = source;
  void persistPreference(RATE_SOURCE_STORAGE_KEY, source);
  updateConversion();
  renderCalculator();
  for (const chip of document.querySelectorAll('.source-picker button[aria-pressed="true"]')) popElement(chip);
  if (source !== "frankfurter") void refreshQuotes({ includeThirdParty: true });
  void refreshHistory();
}

document.addEventListener("click", (event) => {
  const button = event.target.closest(".source-picker button[data-source]");
  if (button) setRateSource(button.dataset.source);
});

function renderQuoteStatus() {
  if (quoteRefreshPending) {
    quotesStatus.textContent = translate("quoteUpdating");
  } else if (lastQuoteCheck) {
    quotesStatus.textContent = translate("quoteLastChecked", { time: formatDateTime(lastQuoteCheck) });
  } else if (lastQuoteSuccesses !== null) {
    quotesStatus.textContent = translate("quoteAvailability", {
      available: lastQuoteSuccesses,
      total: QUOTE_PROVIDERS.length
    });
  } else {
    quotesStatus.textContent = translate("quotesLastCheck");
  }
}

function scheduleQuoteRefresh() {
  window.clearTimeout(quoteRefreshTimeout);
  quotesStatus.textContent = translate("quoteUpdating");
  // Al cambiar de par solo se consulta la fuente oficial; Wise, Xe y TradingView esperan al ciclo o al botón.
  quoteRefreshTimeout = window.setTimeout(() => refreshQuotes({ includeThirdParty: false }), 200);
  scheduleHistoryRefresh();
}

async function refreshQuotes({ includeThirdParty = true, manual = false, only = null } = {}) {
  window.clearTimeout(quoteRefreshTimeout);
  const source = fromSelect.value;
  const target = toSelect.value;
  const now = Date.now();
  const providers = QUOTE_PROVIDERS.filter((provider) => {
    if (only && !only.includes(provider)) return false;
    if (manual) return true;
    if (THIRD_PARTY_PROVIDERS.includes(provider) && !includeThirdParty) return false;
    if ((quoteBackoffUntil[provider] || 0) > now) return false;
    const cached = getQuote(provider, source, target);
    return !cached || now - cached.fetchedAt >= QUOTE_CACHE_TTL_MS;
  });

  if (providers.length === 0) {
    if (quoteAbortController) {
      quoteAbortController.abort();
      quoteAbortController = null;
    }
    quoteRequestSequence += 1;
    quoteRefreshPending = false;
    refreshQuotesButton.disabled = false;
    refreshQuotesButton.classList.remove("is-loading");
    refreshQuotesButton.setAttribute("aria-busy", "false");
    updateQuoteSummary(source, target);
    renderQuotes();
    updateConversion();
    return;
  }

  if (quoteAbortController) quoteAbortController.abort();
  const requestSequence = ++quoteRequestSequence;
  const controller = new AbortController();
  quoteAbortController = controller;
  const timeoutId = window.setTimeout(() => controller.abort(), QUOTE_REQUEST_TIMEOUT_MS);
  refreshQuotesButton.disabled = true;
  refreshQuotesButton.classList.add("is-loading");
  refreshQuotesButton.setAttribute("aria-busy", "true");
  quoteRefreshPending = true;
  renderQuoteStatus();
  for (const provider of providers) {
    quoteErrors[provider] = "";
    quoteFetching[provider] = true;
  }
  renderQuotes();

  try {
    await Promise.allSettled(providers.map(async (provider) => {
      try {
        const quote = await fetchQuote(provider, source, target, controller.signal);
        if (requestSequence !== quoteRequestSequence) return;
        storeQuote(provider, quote);
        quoteErrors[provider] = "";
        delete quoteBackoffUntil[provider];
      } catch (error) {
        if (requestSequence !== quoteRequestSequence) return;
        console.error(`No se pudo consultar la referencia de ${provider}:`, error);
        quoteErrors[provider] = error instanceof Error ? error.message : translate("quoteNoRead");
        if (THIRD_PARTY_PROVIDERS.includes(provider)) {
          quoteBackoffUntil[provider] = Date.now() + QUOTE_BACKOFF_MS;
        }
      }
      quoteFetching[provider] = false;
      renderQuote(provider);
      updateConversion();
    }));
    if (requestSequence !== quoteRequestSequence) return;
    updateConversion();
    updateQuoteSummary(source, target);
  } finally {
    for (const provider of providers) quoteFetching[provider] = false;
    if (requestSequence === quoteRequestSequence) {
      quoteRefreshPending = false;
      renderQuoteStatus();
    }
    window.clearTimeout(timeoutId);
    if (requestSequence === quoteRequestSequence) {
      quoteAbortController = null;
      refreshQuotesButton.disabled = false;
      refreshQuotesButton.classList.remove("is-loading");
      refreshQuotesButton.setAttribute("aria-busy", "false");
    }
  }
}

function updateQuoteSummary(source, target) {
  const available = QUOTE_PROVIDERS
    .map((provider) => getQuote(provider, source, target))
    .filter(Boolean);
  lastQuoteCheck = available.reduce((latest, quote) => Math.max(latest, quote.fetchedAt), 0);
  lastQuoteSuccesses = available.length;
  renderQuoteStatus();
}

function updateOptionSelection(optionsElement, selectedValue) {
  for (const option of optionsElement.querySelectorAll('[role="option"]')) {
    option.setAttribute("aria-selected", String(option.dataset.value === selectedValue));
  }
}

function getVisibleCurrencyOptions(optionsElement) {
  return [...optionsElement.querySelectorAll('[role="option"]')]
    .filter((option) => !option.closest(".currency-option-row").hidden && !option.disabled);
}

function updateCurrencyAvailability(optionsElement) {
  for (const option of optionsElement.querySelectorAll('[role="option"]')) {
    const available = !rates || option.dataset.value === "EUR" || Boolean(rates[option.dataset.value]);
    option.disabled = !available;
    option.setAttribute("aria-disabled", String(!available));
    const status = option.querySelector(".currency-option-status");
    status.textContent = available || !rates ? "" : translate("currencyNoRate");
  }
  const picker = currencyPickers.find((item) => item.optionsElement === optionsElement);
  if (!picker) return;
  for (const favorite of picker.favoritesElement.querySelectorAll(".currency-favorite-shortcut")) {
    const available = !rates || favorite.dataset.value === "EUR" || Boolean(rates[favorite.dataset.value]);
    favorite.disabled = !available;
    favorite.setAttribute("aria-disabled", String(!available));
  }
}

function closeCurrencyPicker(trigger, pickerElement, searchInput, optionsElement, restoreFocus = false) {
  if (pickerElement.hidden) {
    if (restoreFocus) trigger.focus();
    return;
  }
  pickerElement.hidden = true;
  searchInput.value = "";
  for (const row of optionsElement.querySelectorAll(".currency-option-row")) row.hidden = false;
  const favoritesElement = pickerElement.querySelector(".currency-favorite-list");
  for (const favorite of favoritesElement.querySelectorAll(".currency-favorite-shortcut")) favorite.hidden = false;
  const favoritesSection = pickerElement.querySelector(".currency-favorites");
  favoritesSection.hidden = favoritesElement.childElementCount === 0;
  pickerElement.querySelector(".currency-no-results").hidden = true;
  trigger.setAttribute("aria-expanded", "false");
  if (restoreFocus) trigger.focus();
}

function toggleCurrencyPicker(trigger, pickerElement, searchInput, optionsElement) {
  const shouldOpen = pickerElement.hidden;
  for (const [otherTrigger, otherPicker, otherSearch, otherOptions] of [
    [fromTrigger, fromPicker, fromSearch, fromOptions],
    [toTrigger, toPicker, toSearch, toOptions]
  ]) {
    closeCurrencyPicker(otherTrigger, otherPicker, otherSearch, otherOptions);
  }
  if (shouldOpen) {
    currencyPickers.find((item) => item.pickerElement === pickerElement)?.flush();
    pickerElement.hidden = false;
    trigger.setAttribute("aria-expanded", "true");
    searchInput.focus();
  }
}

function initializeCurrencyPicker(
  select,
  trigger,
  pickerElement,
  searchInput,
  optionsElement,
  favoritesElement,
  favoritesSection,
  noResultsElement
) {
  const filterOptions = () => {
    const query = searchInput.value
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLocaleLowerCase(currentLanguage)
      .trim();
    const exactCodeMatch = query
      ? [...optionsElement.querySelectorAll('[role="option"]')]
        .find((option) => option.dataset.value.toLowerCase() === query)
      : null;
    let visibleCount = 0;
    for (const option of optionsElement.querySelectorAll('[role="option"]')) {
      const row = option.closest(".currency-option-row");
      row.hidden = exactCodeMatch
        ? option !== exactCodeMatch
        : !row.dataset.search.includes(query);
      if (!row.hidden) visibleCount += 1;
    }
    for (const favorite of favoritesElement.querySelectorAll(".currency-favorite-shortcut")) {
      favorite.hidden = Boolean(query && !favorite.dataset.search.includes(query));
      if (!favorite.hidden) visibleCount += 1;
    }
    favoritesSection.hidden = favoritesElement.childElementCount === 0 ||
      ![...favoritesElement.children].some((favorite) => !favorite.hidden);
    noResultsElement.hidden = visibleCount > 0;
  };
  const handleSelect = (code) => {
    select.value = code;
    updateCurrencyFlags();
    updateOptionSelection(optionsElement, code);
    updateOptionSelection(toSelect === select ? fromOptions : toOptions, code);
    updateConversion();
    renderQuotes();
    scheduleQuoteRefresh();
    void persistSessionState();
    closeCurrencyPicker(trigger, pickerElement, searchInput, optionsElement);
    trigger.focus();
  };

  const picker = {
    select,
    trigger,
    pickerElement,
    searchInput,
    optionsElement,
    favoritesElement,
    favoritesSection,
    noResultsElement,
    dirty: true,
    // Las ~160 filas se construyen solo al abrir el selector, no al arrancar.
    render: () => {
      picker.dirty = true;
      if (!pickerElement.hidden) picker.flush();
    },
    flush: () => {
      if (!picker.dirty) return;
      picker.dirty = false;
      renderCurrencyOptions(select, optionsElement, favoritesElement, handleSelect);
      updateCurrencyAvailability(optionsElement);
      updateOptionSelection(optionsElement, select.value);
      updateCurrencyFavoriteButtons();
      searchInput.dispatchEvent(new Event("input"));
    },
    renderFavorites: () => renderFavoriteShortcuts(favoritesElement, handleSelect)
  };
  currencyPickers.push(picker);
  searchInput.addEventListener("input", filterOptions);
  trigger.addEventListener("click", () => toggleCurrencyPicker(trigger, pickerElement, searchInput, optionsElement));
  trigger.addEventListener("keydown", (event) => {
    if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      event.preventDefault();
      if (pickerElement.hidden) toggleCurrencyPicker(trigger, pickerElement, searchInput, optionsElement);
    }
  });
  searchInput.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      event.preventDefault();
      closeCurrencyPicker(trigger, pickerElement, searchInput, optionsElement, true);
    } else if (event.key === "ArrowDown") {
      const firstOption = favoritesElement.querySelector(".currency-favorite-shortcut:not([hidden]):not(:disabled)") ||
        getVisibleCurrencyOptions(optionsElement)[0];
      if (firstOption) {
        event.preventDefault();
        firstOption.focus();
      }
    }
  });
  optionsElement.addEventListener("keydown", (event) => {
    const options = getVisibleCurrencyOptions(optionsElement);
    const currentIndex = options.indexOf(document.activeElement);
    let nextIndex = currentIndex;
    if (options.length === 0) return;
    if (event.key === "ArrowDown") nextIndex = (currentIndex + 1) % options.length;
    else if (event.key === "ArrowUp") nextIndex = (currentIndex - 1 + options.length) % options.length;
    else if (event.key === "Home") nextIndex = 0;
    else if (event.key === "End") nextIndex = options.length - 1;
    else if (event.key === "Escape") {
      event.preventDefault();
      closeCurrencyPicker(trigger, pickerElement, searchInput, optionsElement, true);
      return;
    } else {
      return;
    }
    event.preventDefault();
    options[nextIndex].focus();
    options[nextIndex].scrollIntoView({ block: "nearest" });
  });
  favoritesElement.addEventListener("keydown", (event) => {
    if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return;
    const shortcuts = [...favoritesElement.querySelectorAll(".currency-favorite-shortcut:not([hidden]):not(:disabled)")];
    const index = shortcuts.indexOf(document.activeElement);
    if (!shortcuts.length) return;
    event.preventDefault();
    if (event.key === "ArrowDown" && index === shortcuts.length - 1) {
      getVisibleCurrencyOptions(optionsElement)[0]?.focus();
    } else {
      shortcuts[(index + (event.key === "ArrowDown" ? 1 : -1) + shortcuts.length) % shortcuts.length].focus();
    }
  });
}

function formatAmount(value, currency) {
  return new Intl.NumberFormat(currentLanguage, {
    style: "currency",
    currency,
    maximumFractionDigits: 2
  }).format(value);
}

function getReferenceDateRange() {
  const to = new Date().toISOString().slice(0, 10);
  const earliest = new Date(`${to}T12:00:00Z`);
  earliest.setUTCDate(earliest.getUTCDate() - MAX_REFERENCE_AGE_MS / REFRESH_INTERVAL_MS);
  return {
    from: earliest.toISOString().slice(0, 10),
    to
  };
}

function isRecentReferenceDate(referenceDate) {
  const parsed = new Date(`${referenceDate}T12:00:00Z`);
  if (!Number.isFinite(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== referenceDate) {
    return false;
  }
  const { from, to } = getReferenceDateRange();
  return referenceDate >= from && referenceDate <= to;
}

function parseReferenceRates(rows) {
  if (!Array.isArray(rows) || rows.length === 0) {
    throw new Error("El servicio no devolvió observaciones de cambio.");
  }

  const observations = rows.filter((row) =>
    row &&
    row.base === "EUR" &&
    /^[A-Z]{3}$/.test(row.quote) &&
    !NON_CURRENCY_CODES.has(row.quote) &&
    typeof row.date === "string" &&
    /^\d{4}-\d{2}-\d{2}$/.test(row.date) &&
    Number.isFinite(row.rate) &&
    row.rate > 0 &&
    isRecentReferenceDate(row.date)
  );
  if (observations.length === 0) {
    throw new Error("No se encontraron tasas de referencia recientes y válidas.");
  }

  const rates = {};
  for (const { quote, rate, date } of observations) {
    if (!rates[quote] || date > rates[quote].date) rates[quote] = { rate, date };
  }
  const referenceDate = observations.reduce(
    (latest, observation) => observation.date > latest ? observation.date : latest,
    observations[0].date
  );
  return { rates, referenceDate };
}

function applyCachedRates(cache) {
  if (rates || !cache || typeof cache !== "object" || !cache.rates || typeof cache.rates !== "object") return;
  if (typeof cache.referenceDate !== "string" || !isRecentReferenceDate(cache.referenceDate)) return;
  if (!Number.isFinite(cache.fetchedAt)) return;
  const cachedRates = {};
  for (const [code, entry] of Object.entries(cache.rates)) {
    if (
      /^[A-Z]{3}$/.test(code) &&
      entry && Number.isFinite(entry.rate) && entry.rate > 0 &&
      typeof entry.date === "string" && isRecentReferenceDate(entry.date)
    ) {
      cachedRates[code] = { rate: entry.rate, date: entry.date };
    }
  }
  if (Object.keys(cachedRates).length === 0) return;
  rates = cachedRates;
  referenceDate = cache.referenceDate;
  nextRefreshAt = cache.fetchedAt + REFRESH_INTERVAL_MS;
  rateStatusKey = "statusDaily";
  rebuildCurrencyCatalogue();
  setUpdatedLabel(referenceDate, cache.fetchedAt);
  statusElement.textContent = translate("statusDaily");
  updateConversion();
  if (!panelCrypto.hidden) renderCrypto();
}

function rebuildCurrencyCatalogue() {
  const codes = new Set([...Object.keys(CURRENCY_REGIONS), ...Object.keys(rates || {})]);
  const signature = `${currentLanguage}|${[...codes].sort().join(",")}`;
  if (signature === catalogueSignature) {
    for (const picker of currencyPickers) updateCurrencyAvailability(picker.optionsElement);
    return;
  }
  catalogueSignature = signature;
  CURRENCIES = [...codes]
    .filter((code) => /^[A-Z]{3}$/.test(code) && !NON_CURRENCY_CODES.has(code))
    .map((code) => createCurrency(code))
    .sort((left, right) =>
      left.country.localeCompare(right.country, currentLanguage) ||
      left.code.localeCompare(right.code)
    );

  for (const picker of currencyPickers) {
    const selectedCode = picker.select.value;
    picker.select.replaceChildren();
    populateCurrencySelect(picker.select);
    picker.select.value = selectedCode;
    picker.render();
    updateCurrencyAvailability(picker.optionsElement);
    updateOptionSelection(picker.optionsElement, selectedCode);
  }
  updateCurrencyFavoriteButtons();
  for (const picker of currencyPickers) {
    picker.searchInput.dispatchEvent(new Event("input"));
  }
  updateCurrencyFlags();
}

function updateConversion() {
  renderSourcePickers();
  updateConversionCore();
  const from = fromSelect.value;
  const to = toSelect.value;
  if (rateSource !== "frankfurter" && from !== to && !pickedQuote(from, to) && conversionSourceElement.textContent) {
    conversionSourceElement.textContent += ` · ${translate("sourceMissing", { source: providerLabel(rateSource) })}`;
  }
}

function updateConversionCore() {
  copyableResult = null;
  copyFeedback.textContent = "";
  copyLabel.textContent = translate("copyPrompt");
  conversionSourceElement.textContent = "";
  conversionSourceElement.title = "";
  const amount = parseAmount(amountInput.value);
  const from = fromSelect.value;
  const to = toSelect.value;

  if (amountInput.value.trim() === "" || !Number.isFinite(amount) || amount < 0) {
    resultElement.textContent = translate("amountInvalid");
    rateElement.textContent = translate("amountNonnegative");
    return;
  }

  if (from === to) {
    resultElement.textContent = formatAmount(amount, to);
    copyableResult = resultElement.textContent;
    conversionSourceElement.textContent = translate("conversionSourceLocal");
    rateElement.textContent = `1 ${from} = 1 ${to}`;
    return;
  }

  const picked = pickedQuote(from, to);
  if (picked) {
    const { provider, quote } = picked;
    conversionSourceElement.textContent = translate("conversionSourcePicked", { source: providerLabel(provider) });
    conversionSourceElement.title = [formatQuoteTime(quote), quote.providerTimestamp].filter(Boolean).join(" · ");
    resultElement.textContent = formatAmount(amount * quote.rate, to);
    copyableResult = resultElement.textContent;
    rateElement.textContent = `1 ${from} = ${new Intl.NumberFormat(currentLanguage, {
      maximumSignificantDigits: 7
    }).format(quote.rate)} ${to} · ${formatQuoteTime(quote)}`;
    return;
  }

  const fromRate = rates && (from === "EUR" ? 1 : rates[from]?.rate);
  const toRate = rates && (to === "EUR" ? 1 : rates[to]?.rate);
  const primaryRateAvailable = Number.isFinite(fromRate) && Number.isFinite(toRate);
  const fallback = getFallbackQuote(from, to);

  if (fallback && (!primaryRateAvailable || primarySourceUnavailable)) {
    const { provider, quote } = fallback;
    conversionSourceElement.textContent = translate("conversionSourceFallback", {
      source: getQuoteProviderName(provider)
    });
    conversionSourceElement.title = [
      formatQuoteTime(quote),
      quote.providerTimestamp
    ].filter(Boolean).join(" · ");
    const amountConverted = amount * quote.rate;
    resultElement.textContent = formatAmount(amountConverted, to);
    copyableResult = resultElement.textContent;
    rateElement.textContent = `1 ${from} = ${new Intl.NumberFormat(currentLanguage, {
      maximumSignificantDigits: 7
    }).format(quote.rate)} ${to} · ${formatQuoteTime(quote)}`;
    return;
  }

  if (!primaryRateAvailable) {
    if (!rates) {
      resultElement.textContent = "—";
      rateElement.textContent = translate("waitingRates");
      return;
    }
    resultElement.textContent = translate("unavailable");
    rateElement.textContent = translate("missingRate", { code: !Number.isFinite(fromRate) ? from : to });
    return;
  }

  conversionSourceElement.textContent = translate(primarySourceUnavailable
    ? "conversionSourceCached"
    : "conversionSourceMain");
  const exchangeRate = toRate / fromRate;
  resultElement.textContent = formatAmount(amount * exchangeRate, to);
  copyableResult = resultElement.textContent;
  const sourceDate = from === "EUR"
    ? (to === "EUR" ? referenceDate : rates[to].date)
    : rates[from].date;
  const targetDate = to === "EUR" ? sourceDate : rates[to].date;
  const dateLabel = sourceDate === targetDate
    ? translate("rateDateSingle", { date: formatReferenceDate(sourceDate) })
    : translate("rateDatePair", {
      sourceDate: formatReferenceDate(sourceDate),
      targetDate: formatReferenceDate(targetDate)
    });
  rateElement.textContent = `1 ${from} = ${new Intl.NumberFormat(currentLanguage, {
    maximumSignificantDigits: 7
  }).format(exchangeRate)} ${to}${dateLabel}`;
}

async function copyConversionResult() {
  if (!copyableResult) {
    copyFeedback.textContent = translate("copyWaiting");
    return;
  }

  try {
    await navigator.clipboard.writeText(copyableResult);
    copyLabel.textContent = translate("copied");
    copyFeedback.textContent = translate("copySuccess");
    celebrate(copyResultButton);
  } catch (error) {
    console.error("No se pudo copiar el resultado al portapapeles:", error);
    copyLabel.textContent = translate("copyFailure");
    copyFeedback.textContent = translate("copyManual");
  }
}

function setUpdatedLabel(dateValue, fetchedAt = Date.now()) {
  if (!isRecentReferenceDate(dateValue)) {
    throw new Error("La fecha de actualización recibida no es válida.");
  }
  referenceFetchedAt = fetchedAt;
  updatedElement.title = "";
  const formattedDate = formatReferenceDate(dateValue);
  updatedElement.textContent = translate("marketUpdate", {
    date: formattedDate,
    time: new Intl.DateTimeFormat(currentLanguage, {
    hour: "2-digit",
    minute: "2-digit"
    }).format(new Date(fetchedAt))
  });
}

function formatReferenceDate(dateValue) {
  return new Intl.DateTimeFormat(currentLanguage, {
    dateStyle: "medium",
    timeZone: "UTC"
  }).format(new Date(`${dateValue}T12:00:00Z`));
}

function setLoading(isLoading) {
  refreshInProgress = isLoading;
  refreshButton.disabled = isLoading;
  refreshButton.classList.toggle("is-loading", isLoading);
  refreshButton.setAttribute("aria-busy", String(isLoading));
}

async function refreshRates(force = false) {
  if (refreshInProgress) return;
  if (rates && Date.now() < nextRefreshAt && !force) return;

  setLoading(true);
  if (!rates) statusElement.textContent = translate("statusLoading");
  if (!rates) rateStatusKey = "statusLoading";
  let requestTimedOut = false;
  const controller = new AbortController();
  const timeoutId = window.setTimeout(() => {
    requestTimedOut = true;
    controller.abort();
  }, CURRENCY_REQUEST_TIMEOUT_MS);
  try {
    const url = new URL(CURRENCY_API_URL);
    const { from, to } = getReferenceDateRange();
    url.searchParams.set("from", from);
    url.searchParams.set("to", to);
    const response = await fetch(url, {
      cache: "no-store",
      signal: controller.signal
    });
    if (!response.ok) {
      throw new Error(`Frankfurter respondió con el código ${response.status}.`);
    }

    const referenceData = parseReferenceRates(await response.json());
    const fetchedAt = Date.now();
    nextRefreshAt = fetchedAt + REFRESH_INTERVAL_MS;
    rates = referenceData.rates;
    referenceDate = referenceData.referenceDate;
    primarySourceUnavailable = false;
    rateErrorDetail = "";
    rebuildCurrencyCatalogue();
    setUpdatedLabel(referenceDate, fetchedAt);
    if (!panelCrypto.hidden) renderCrypto();
    void persistPreference(RATES_CACHE_STORAGE_KEY, { rates, referenceDate, fetchedAt });
    statusElement.textContent = translate("statusDaily");
    rateStatusKey = "statusDaily";
    updateConversion();
  } catch (error) {
    primarySourceUnavailable = true;
    const reportedError = requestTimedOut
      ? new Error(`Frankfurter no respondió en ${CURRENCY_REQUEST_TIMEOUT_MS / 1000} segundos.`)
      : error;
    console.error("No se pudieron consultar las referencias de Frankfurter:", reportedError);
    if (rates) {
      statusElement.textContent = translate("statusNoConnection");
      rateStatusKey = "statusNoConnection";
      updateConversion();
    } else {
      statusElement.textContent = translate("statusFailure");
      rateStatusKey = "statusFailure";
      updatedElement.textContent = translate("rateRequestFailed");
      rateErrorDetail = reportedError instanceof Error ? reportedError.message : "";
      updatedElement.title = rateErrorDetail;
      resultElement.textContent = translate("noOfficialData");
      rateElement.textContent = translate("retryUpdate");
    }
  } finally {
    window.clearTimeout(timeoutId);
    setLoading(false);
  }
}

populateCurrencySelect(fromSelect);
populateCurrencySelect(toSelect);
fromSelect.value = "USD";
toSelect.value = "EUR";
updateCurrencyFlags();
initializeCurrencyPicker(fromSelect, fromTrigger, fromPicker, fromSearch, fromOptions, fromFavorites, fromPicker.querySelector(".currency-favorites"), fromNoResults);
initializeCurrencyPicker(toSelect, toTrigger, toPicker, toSearch, toOptions, toFavorites, toPicker.querySelector(".currency-favorites"), toNoResults);

document.addEventListener("click", (event) => {
  for (const picker of currencyPickers) {
    if (!picker.trigger.parentElement.contains(event.target)) {
      closeCurrencyPicker(picker.trigger, picker.pickerElement, picker.searchInput, picker.optionsElement);
    }
  }
});

for (const control of [amountInput, fromSelect, toSelect]) {
  control.addEventListener("input", () => {
    if (control === fromSelect || control === toSelect) {
      updateCurrencyFlags();
      scheduleQuoteRefresh();
    }
    updateConversion();
    renderQuotes();
    void persistSessionState();
  });
  control.addEventListener("change", () => {
    if (control === fromSelect || control === toSelect) {
      updateCurrencyFlags();
      scheduleQuoteRefresh();
    }
    updateConversion();
    renderQuotes();
    void persistSessionState();
  });
}

swapButton.addEventListener("click", () => {
  const previousFrom = fromSelect.value;
  fromSelect.value = toSelect.value;
  toSelect.value = previousFrom;
  updateCurrencyFlags();
  updateOptionSelection(fromOptions, fromSelect.value);
  updateOptionSelection(toOptions, toSelect.value);
  updateConversion();
  renderQuotes();
  scheduleQuoteRefresh();
  void persistSessionState();
});

// Un único botón actualiza tasas, cotizaciones y gráfico.
async function refreshEverything() {
  refreshButton.setAttribute("aria-busy", "true");
  await Promise.allSettled([refreshRates(true), refreshQuotes({ manual: true }), refreshHistory()]);
  refreshButton.setAttribute("aria-busy", String(refreshInProgress));
}
refreshButton.addEventListener("click", refreshEverything);
refreshQuotesButton.addEventListener("click", () => refreshQuotes({ manual: true }));
themeSelect.addEventListener("change", () => {
  setTheme(themeSelect.value, { persist: true });
  void persistSessionState();
});
copyResultButton.addEventListener("click", copyConversionResult);
languageDialogSelect.addEventListener("change", () => {
  setLanguage(languageDialogSelect.value);
  void persistSessionState();
});
languageContinueButton.addEventListener("click", () => startSession());
languageSelect.addEventListener("change", async () => {
  setLanguage(languageSelect.value);
  void persistSessionState();
  await persistPreference(LANGUAGE_STORAGE_KEY, languageSelect.value);
});
async function initialize() {
  try {
    updateConversion();
    renderQuotes();
    // Lo esencial (tasas) arranca ya; cotizaciones de terceros e histórico esperan a que se vean:
    // en la pestaña Divisas casi de inmediato; en la calculadora, hasta que se abra Divisas.
    const essential = refreshRates();
    // La fuente elegida (Wise por defecto) se pide enseguida; el resto, solo si se abre Divisas.
    const chosen = providerOf(rateSource);
    window.setTimeout(() => {
      if (currentTab === "fx") {
        void refreshQuotes({ includeThirdParty: true });
        void refreshHistory();
      } else {
        void refreshQuotes({ includeThirdParty: true, only: ["ecb", chosen] });
      }
    }, 200);
    await essential;
  } catch (error) {
    console.error("No se pudo iniciar Divisa&Go:", error);
    statusElement.textContent = translate("initFailure");
    updatedElement.textContent = translate("initRetry");
  }
}


// ---- Evolución histórica ----
const HISTORY_PERIODS = {
  "1W": { days: 7 },
  "1M": { days: 30 },
  "3M": { days: 91 },
  "6M": { days: 182, group: "week" },
  "1Y": { days: 365, group: "week" },
  "5Y": { days: 1826, group: "week" }
};
const HISTORY_CACHE_TTL_MS = 30 * 60 * 1000;
const historyPeriodsElement = document.querySelector("#history-periods");
const historyPair = document.querySelector("#history-pair");
const historyLast = document.querySelector("#history-last");
const historyChange = document.querySelector("#history-change");
const historyChart = document.querySelector("#history-chart");
const historySvg = document.querySelector("#history-svg");
const historyTooltip = document.querySelector("#history-tooltip");
const historyMessage = document.querySelector("#history-message");
const historyMin = document.querySelector("#history-min");
const historyMax = document.querySelector("#history-max");
const historyCache = new Map();
let historyPeriod = "1M";
let historyProvider = "frankfurter";
let historyNoteKey = "";
let historyNoteSource = "";
const historyNote = document.querySelector("#history-note");
let historyPoints = [];
let historyMessageKey = "";
let historyTimeout = 0;
let historyController = null;
let historySequence = 0;
let historyCursor = null;

function formatRateValue(value) {
  return new Intl.NumberFormat(currentLanguage, { maximumSignificantDigits: 6 }).format(value);
}

function scheduleHistoryRefresh() {
  window.clearTimeout(historyTimeout);
  historyTimeout = window.setTimeout(() => refreshHistory(), 200);
}

async function fetchFrankfurterHistory(source, target, period, signal) {
  const { days, group } = HISTORY_PERIODS[period];
  const end = new Date();
  const from = new Date(end.getTime() - days * 86400000).toISOString().slice(0, 10);
  const to = end.toISOString().slice(0, 10);
  const url = new URL(CURRENCY_API_URL);
  url.searchParams.set("base", source);
  url.searchParams.set("quotes", target);
  url.searchParams.set("from", from);
  url.searchParams.set("to", to);
  if (group) url.searchParams.set("group", group);
  const response = await fetch(url, { signal });
  if (!response.ok) throw new Error(`Frankfurter respondió con el código ${response.status}.`);
  const rows = await response.json();
  return (Array.isArray(rows) ? rows : [])
    .filter((row) => row && typeof row.date === "string" && Number.isFinite(row.rate) && row.rate > 0)
    .map((row) => ({ date: row.date, rate: row.rate }))
    .sort((a, b) => a.date.localeCompare(b.date));
}

async function fetchWiseHistory(source, target, period, signal) {
  const [length, unit] = WISE_RANGES[period];
  const raw = await fetchWiseSeries(source, target, length, unit, "daily", signal);
  const byDay = new Map();
  for (const point of raw) byDay.set(new Date(point.time).toISOString().slice(0, 10), point.rate);
  let points = [...byDay].map(([date, rate]) => ({ date, rate })).sort((a, b) => a.date.localeCompare(b.date));
  if (points.length > 260) {
    const step = Math.ceil(points.length / 260);
    points = points.filter((_, index) => index % step === 0 || index === points.length - 1);
  }
  return points;
}

function applyHistoryEntry(entry) {
  historyPoints = entry.points;
  historyProvider = entry.provider;
  historyNoteKey = entry.noteKey || "";
  historyNoteSource = entry.noteSource || "";
  historyMessageKey = entry.points.length > 1 ? "" : "historyEmpty";
}

// El gráfico sigue a la fuente elegida: Wise tiene histórico propio; Xe y TradingView no lo publican
// y Frankfurter es la referencia diaria, así que en esos casos se muestra Frankfurter y se avisa.
async function refreshHistory() {
  window.clearTimeout(historyTimeout);
  const source = fromSelect.value;
  const target = toSelect.value;
  const period = historyPeriod;
  if (historyController) historyController.abort();
  const sequence = ++historySequence;

  if (source === target) {
    historyPoints = [];
    historyMessageKey = "historySame";
    renderHistory();
    return;
  }
  const today = new Date().toISOString().slice(0, 10);
  const key = `${rateSource}/${source}/${target}/${period}/${today}`;
  const cached = historyCache.get(key);
  if (cached && Date.now() - cached.at < HISTORY_CACHE_TTL_MS) {
    applyHistoryEntry(cached);
    renderHistory();
    return;
  }

  historyPoints = [];
  historyProvider = rateSource === "wise" ? "wise" : "frankfurter";
  historyNoteKey = "";
  historyMessageKey = "historyLoading";
  renderHistory();
  const controller = new AbortController();
  historyController = controller;
  const timeoutId = window.setTimeout(() => controller.abort(), CURRENCY_REQUEST_TIMEOUT_MS);
  try {
    let provider = "frankfurter";
    let points = null;
    let noteKey = "";
    let noteSource = "";
    if (rateSource === "wise") {
      try {
        points = await withRetry(() => fetchWiseHistory(source, target, period, controller.signal), controller.signal);
        provider = "wise";
      } catch (error) {
        if (controller.signal.aborted) throw error;
        console.error("No se pudo cargar el histórico de Wise:", error);
        noteKey = "historyFallback";
        noteSource = "Wise";
      }
    } else if (rateSource === "xe" || rateSource === "tradingview") {
      noteKey = "historyNoData";
      noteSource = providerLabel(rateSource);
    }
    if (!points) points = await withRetry(() => fetchFrankfurterHistory(source, target, period, controller.signal), controller.signal);
    if (sequence !== historySequence) return;
    const entry = { points, at: Date.now(), provider, noteKey, noteSource };
    historyCache.set(key, entry);
    scheduleLiveCachePersist();
    applyHistoryEntry(entry);
  } catch (error) {
    if (sequence !== historySequence) return;
    console.error("No se pudo cargar la evolución:", error);
    historyPoints = [];
    historyMessageKey = "historyError";
  } finally {
    window.clearTimeout(timeoutId);
  }
  renderHistory();
}

function renderHistory() {
  historyPair.textContent = `${fromSelect.value} → ${toSelect.value} · ${historyProvider === "wise" ? "Wise" : "Frankfurter"}`;
  historyNote.textContent = historyNoteKey ? translate(historyNoteKey, { source: historyNoteSource }) : "";
  for (const button of historyPeriodsElement.querySelectorAll("button")) {
    button.setAttribute("aria-pressed", String(button.dataset.period === historyPeriod));
  }
  historyTooltip.hidden = true;
  historyMessage.textContent = historyMessageKey ? translate(historyMessageKey) : "";
  historySvg.replaceChildren();
  historyCursor = null;
  historyChange.textContent = "";
  historyChange.className = "history-change";
  historyLast.textContent = "—";
  historyMin.textContent = "";
  historyMax.textContent = "";
  if (historyPoints.length < 2 || historyMessageKey) return;

  const rates = historyPoints.map((point) => point.rate);
  const min = Math.min(...rates);
  const max = Math.max(...rates);
  const span = max - min || min * 0.01 || 1;
  const width = 380;
  const height = 130;
  const pad = 6;
  const t0 = Date.parse(historyPoints[0].date);
  const t1 = Date.parse(historyPoints.at(-1).date);
  for (const point of historyPoints) {
    point.x = pad + ((Date.parse(point.date) - t0) / (t1 - t0 || 1)) * (width - pad * 2);
    point.y = height - pad - ((point.rate - min) / span) * (height - pad * 2);
  }

  const line = historyPoints
    .map((point, index) => `${index ? "L" : "M"}${point.x.toFixed(1)} ${point.y.toFixed(1)}`)
    .join("");
  const svgNs = "http://www.w3.org/2000/svg";
  const area = document.createElementNS(svgNs, "path");
  area.setAttribute("class", "history-area");
  area.setAttribute("d", `${line}L${historyPoints.at(-1).x.toFixed(1)} ${height}L${historyPoints[0].x.toFixed(1)} ${height}Z`);
  const path = document.createElementNS(svgNs, "path");
  path.setAttribute("class", "history-line");
  path.setAttribute("d", line);
  historyCursor = document.createElementNS(svgNs, "line");
  historyCursor.setAttribute("class", "history-cursor");
  historyCursor.setAttribute("y1", "0");
  historyCursor.setAttribute("y2", String(height));
  historyCursor.setAttribute("visibility", "hidden");
  historySvg.append(area, path, historyCursor);

  const first = rates[0];
  const last = rates.at(-1);
  const change = ((last - first) / first) * 100;
  historyLast.textContent = `1 ${fromSelect.value} = ${formatRateValue(last)} ${toSelect.value}`;
  historyChange.textContent = `${change >= 0 ? "▲" : "▼"} ${Math.abs(change).toFixed(2)}%`;
  historyChange.classList.add(change >= 0 ? "is-up" : "is-down");
  historyMin.textContent = translate("historyMin", { value: formatRateValue(min) });
  historyMax.textContent = translate("historyMax", { value: formatRateValue(max) });
}

historyChart.addEventListener("pointermove", (event) => {
  if (historyPoints.length < 2 || historyMessageKey || !historyCursor) return;
  const box = historyChart.getBoundingClientRect();
  const svgX = ((event.clientX - box.left) / box.width) * 380;
  let nearest = historyPoints[0];
  for (const point of historyPoints) {
    if (Math.abs(point.x - svgX) < Math.abs(nearest.x - svgX)) nearest = point;
  }
  historyCursor.setAttribute("x1", nearest.x);
  historyCursor.setAttribute("x2", nearest.x);
  historyCursor.setAttribute("visibility", "visible");
  historyTooltip.textContent = `${formatReferenceDate(nearest.date)} · ${formatRateValue(nearest.rate)}`;
  historyTooltip.hidden = false;
  const left = Math.min(Math.max((nearest.x / 380) * box.width, 70), box.width - 70);
  historyTooltip.style.left = `${left}px`;
});
historyChart.addEventListener("pointerleave", () => {
  historyTooltip.hidden = true;
  historyCursor?.setAttribute("visibility", "hidden");
});
historyPeriodsElement.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-period]");
  if (!button || button.dataset.period === historyPeriod) return;
  historyPeriod = button.dataset.period;
  void persistSessionState();
  void refreshHistory();
});

// ---- Preguntas frecuentes (ventana modal) ----
const faqOverlay = document.querySelector("#faq-overlay");
const faqList = document.querySelector("#faq-list");

function renderFaq() {
  const items = [];
  for (let number = 1; number <= 10; number += 1) {
    if (number === 8) continue;
    items.push({ question: translate(`faqQ${number}`), answer: translate(`faqA${number}`), html: false });
  }
  // Las preguntas antiguas llevan la pregunta en <strong> y la respuesta (con enlaces) a continuación.
  for (const key of ["faqFavorites", "faqReadme"]) {
    const match = translate(key).match(/^<strong>(.*?)<\/strong>\s*([\s\S]*)$/);
    if (match) items.push({ question: match[1], answer: match[2], html: true });
  }
  faqList.replaceChildren(...items.map((item, index) => {
    const details = document.createElement("details");
    details.className = "faq-item";
    const summary = document.createElement("summary");
    summary.textContent = item.question;
    const answer = document.createElement("p");
    if (item.html) answer.innerHTML = item.answer;
    else answer.textContent = item.answer;
    details.append(summary, answer);
    if (index === 0) details.open = true;
    return details;
  }));
  const footer = document.createElement("p");
  footer.className = "faq-footer";
  footer.innerHTML = translate("faqResources");
  faqList.append(footer);
}

function openFaq() {
  renderFaq();
  faqOverlay.hidden = false;
  appShell.inert = true;
  document.querySelector("#faq-close").focus({ preventScroll: true });
}

function closeFaq() {
  faqOverlay.hidden = true;
  appShell.inert = !tutorialOverlay.hidden;
  document.querySelector("#faq-open").focus({ preventScroll: true });
}

document.querySelector("#faq-open").addEventListener("click", openFaq);
document.querySelector("#faq-close").addEventListener("click", closeFaq);
faqOverlay.addEventListener("click", (event) => {
  if (event.target === faqOverlay) closeFaq();
});
faqOverlay.addEventListener("keydown", (event) => {
  if (event.key === "Escape") closeFaq();
});

// ---- Tutorial guiado ----
const TUTORIAL_STEPS = [
  { n: 1, tab: "calc", target: () => document.querySelector("#tabs-nav") },
  { n: 2, tab: "calc", target: () => document.querySelector("#calc-display") },
  { n: 3, tab: "calc", target: () => document.querySelector("#calc-margins") },
  { n: 4, tab: "calc", target: () => document.querySelector(".calc-actions") },
  { n: 5, tab: "fx", target: () => document.querySelector(".converter-card") },
  { n: 6, tab: "fx", target: () => document.querySelector("#source-picker-fx") },
  { n: 7, tab: "fx", target: () => document.querySelector("#quote-wise") },
  { n: 9, tab: "calc", target: null }
];
const tutorialOverlay = document.querySelector("#tutorial-overlay");
const tutorialSpot = document.querySelector("#tutorial-spot");
const tutorialDialog = tutorialOverlay.querySelector(".tutorial-dialog");
const tutorialStepLabel = document.querySelector("#tutorial-step");
const tutorialTitle = document.querySelector("#tutorial-title");
const tutorialText = document.querySelector("#tutorial-text");
const tutorialDots = document.querySelector("#tutorial-dots");
const tutorialBack = document.querySelector("#tutorial-back");
const tutorialNext = document.querySelector("#tutorial-next");
let tutorialIndex = 0;
let tutorialReturnTab = "calc";

function positionTutorial() {
  const step = TUTORIAL_STEPS[tutorialIndex];
  const target = step.target?.() ?? null;
  if (!target || target.getClientRects().length === 0) {
    tutorialOverlay.classList.remove("has-target");
    tutorialSpot.hidden = true;
    tutorialDialog.style.top = "";
    tutorialDialog.style.left = "";
    return;
  }
  target.scrollIntoView({ block: "center", inline: "nearest" });
  const rect = target.getBoundingClientRect();
  tutorialOverlay.classList.add("has-target");
  tutorialSpot.hidden = false;
  const pad = 4;
  tutorialSpot.style.left = `${rect.left - pad}px`;
  tutorialSpot.style.top = `${rect.top - pad}px`;
  tutorialSpot.style.width = `${rect.width + pad * 2}px`;
  tutorialSpot.style.height = `${rect.height + pad * 2}px`;
  const viewHeight = window.innerHeight;
  const viewWidth = window.innerWidth;
  const height = tutorialDialog.offsetHeight;
  const width = tutorialDialog.offsetWidth;
  let top = rect.bottom + pad + 10;
  if (top + height > viewHeight - 8) top = rect.top - pad - 10 - height;
  if (top < 8) top = Math.max(8, viewHeight - height - 8);
  const left = Math.min(Math.max(rect.left + rect.width / 2 - width / 2, 8), viewWidth - width - 8);
  tutorialDialog.style.top = `${top}px`;
  tutorialDialog.style.left = `${left}px`;
}

function renderTutorialStep() {
  const number = tutorialIndex + 1;
  const total = TUTORIAL_STEPS.length;
  const textNumber = TUTORIAL_STEPS[tutorialIndex].n;
  tutorialStepLabel.textContent = translate("tutorialStep", { current: number, total });
  tutorialTitle.textContent = translate(`tutorial${textNumber}Title`);
  tutorialText.textContent = translate(`tutorial${textNumber}Text`);
  tutorialBack.hidden = tutorialIndex === 0;
  tutorialNext.textContent = translate(number === total ? "tutorialDone" : "tutorialNext");
  tutorialDots.replaceChildren(...Array.from({ length: total }, (_, index) => {
    const dot = document.createElement("span");
    dot.className = index === tutorialIndex ? "is-active" : "";
    return dot;
  }));
  if (tutorialOverlay.hidden) return;
  replayAnimation(tutorialDialog, "fx-step");
  const step = TUTORIAL_STEPS[tutorialIndex];
  if (step.tab && currentTab !== step.tab) selectTab(step.tab, { persist: false });
  positionTutorial();
}

function openTutorial() {
  tutorialIndex = 0;
  tutorialReturnTab = currentTab;
  tutorialOverlay.hidden = false;
  appShell.inert = true;
  renderTutorialStep();
  tutorialNext.focus({ preventScroll: true });
}

function closeTutorial() {
  tutorialOverlay.hidden = true;
  tutorialOverlay.classList.remove("has-target");
  tutorialSpot.hidden = true;
  appShell.inert = false;
  if (!tutorialDone) {
    tutorialDone = true;
    void persistPreference(TUTORIAL_STORAGE_KEY, true);
  }
  // Al terminar (o saltar) el tutorial se llega a la pestaña principal: el conversor de divisas.
  selectTab("fx");
  document.activeElement?.blur?.();
  setPageScroll(0);
}
window.addEventListener("resize", () => {
  if (!tutorialOverlay.hidden) positionTutorial();
});

tutorialNext.addEventListener("click", () => {
  if (tutorialIndex >= TUTORIAL_STEPS.length - 1) closeTutorial();
  else {
    tutorialIndex += 1;
    renderTutorialStep();
  }
});
tutorialBack.addEventListener("click", () => {
  if (tutorialIndex > 0) {
    tutorialIndex -= 1;
    renderTutorialStep();
  }
});
document.querySelector("#tutorial-skip").addEventListener("click", closeTutorial);
document.querySelector("#tutorial-open").addEventListener("click", openTutorial);
tutorialOverlay.addEventListener("keydown", (event) => {
  if (event.key === "Escape") closeTutorial();
});


// ---- Banner de publicidad ----
const adBanner = document.querySelector("#ad-banner");
const adLink = document.querySelector("#ad-link");
const adText = document.querySelector("#ad-text");
const adCta = document.querySelector("#ad-cta");
const adRemove = document.querySelector("#ad-remove");
let adIndex = 0;

function getValidAds() {
  return ADS.filter((ad) => {
    try {
      return new URL(ad.url).protocol === "https:";
    } catch {
      return false;
    }
  });
}

function localizedAdText(value) {
  if (!value || typeof value === "string") return value || "";
  return value[currentLanguage] ?? value.es ?? value.en ?? "";
}

function showAd(ads, index = adIndex) {
  const ad = ads[index % ads.length];
  adText.textContent = localizedAdText(ad.text);
  adCta.textContent = localizedAdText(ad.cta);
  adLink.href = new URL(ad.url).href;
  if (index === adIndex) adIndex += 1;
}

document.querySelector("#ad-close").addEventListener("click", () => {
  adDismissed = true;
  adBanner.hidden = true;
  document.body.classList.remove("has-ad");
  void persistPreference(AD_DISMISSED_STORAGE_KEY, true);
});

function startAdBanner() {
  const ads = getValidAds();
  if (premiumUser || adDismissed || ads.length === 0) return;
  showAd(ads);
  adBanner.hidden = false;
  document.body.classList.add("has-ad");
  if (REMOVE_ADS_URL) {
    adRemove.href = REMOVE_ADS_URL;
    adRemove.hidden = false;
  }
  if (ads.length > 1) {
    window.setInterval(() => { if (!document.hidden) showAd(ads); }, AD_ROTATION_MS);
  }
}


// ---- Copias automáticas ----
const autoBackupList = document.querySelector("#auto-backup-list");
const autoBackupNow = document.querySelector("#auto-backup-now");
let autoBackupConfirmId = null;
let autoBackupConfirmTimeout = 0;

async function renderAutoBackups() {
  const backups = await divisagoBackup.list();
  if (backups.length === 0) {
    const empty = document.createElement("li");
    empty.className = "auto-backup-empty";
    empty.textContent = translate("autoBackupEmpty");
    autoBackupList.replaceChildren(empty);
    return;
  }
  autoBackupList.replaceChildren(...backups.map((backup) => {
    const item = document.createElement("li");
    const info = document.createElement("span");
    const date = new Intl.DateTimeFormat(currentLanguage, { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }).format(backup.at);
    const reason = translate({ update: "autoBackupUpdate", manual: "autoBackupManual" }[backup.reason] ?? "autoBackupDaily");
    info.innerHTML = "<strong></strong><small></small>";
    info.firstChild.textContent = `${date} · ${reason}`;
    info.lastChild.textContent = translate("autoBackupSummary", {
      favorites: backup.favorites,
      margins: backup.margins,
      templates: backup.templates
    });
    const button = document.createElement("button");
    button.type = "button";
    button.dataset.restore = String(backup.id);
    button.textContent = translate(autoBackupConfirmId === backup.id ? "autoBackupConfirm" : "autoBackupRestore");
    button.classList.toggle("is-confirm", autoBackupConfirmId === backup.id);
    item.append(info, button);
    return item;
  }));
}

autoBackupList.addEventListener("click", async (event) => {
  const button = event.target.closest("button[data-restore]");
  if (!button) return;
  const id = Number(button.dataset.restore);
  if (autoBackupConfirmId !== id) {
    autoBackupConfirmId = id;
    window.clearTimeout(autoBackupConfirmTimeout);
    autoBackupConfirmTimeout = window.setTimeout(() => {
      autoBackupConfirmId = null;
      void renderAutoBackups();
    }, 4000);
    void renderAutoBackups();
    return;
  }
  autoBackupConfirmId = null;
  if (await divisagoBackup.restore(id)) {
    backupFeedback.textContent = translate("autoBackupRestored");
    window.setTimeout(() => location.reload(), 700);
  }
});
autoBackupNow.addEventListener("click", async () => {
  const saved = await divisagoBackup.snapshot("manual");
  backupFeedback.textContent = translate(saved ? "autoBackupDone" : "autoBackupEmpty");
  void renderAutoBackups();
});
void renderAutoBackups();

// ---- Copia de seguridad de favoritos ----
const backupExportButton = document.querySelector("#backup-export");
const backupImportButton = document.querySelector("#backup-import");
const backupInput = document.querySelector("#backup-input");
const backupFeedback = document.querySelector("#backup-feedback");

function parseBackup(text) {
  const data = JSON.parse(text);
  const favorites = Array.isArray(data) ? data : data?.favorites;
  if (!Array.isArray(favorites) && !Array.isArray(data?.margins)) throw new Error("Formato no válido");
  return {
    favorites: Array.isArray(favorites)
      ? [...new Set(favorites.filter((code) => typeof code === "string" && /^[A-Z]{3}$/.test(code)))]
      : [],
    // Las copias antiguas no traen márgenes: null deja los actuales como están.
    margins: Array.isArray(data?.margins) ? normalizeMargins(data.margins) : null
  };
}

backupExportButton.addEventListener("click", () => {
  if (favoriteCurrencies.length === 0 && calcMargins.length === 0) {
    backupFeedback.textContent = translate("backupEmpty");
    return;
  }
  const backup = {
    app: "Divisa&Go",
    version: 2,
    exportedAt: new Date().toISOString(),
    favorites: favoriteCurrencies,
    margins: calcMargins
  };
  const blob = new Blob([JSON.stringify(backup, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `divisago-copia-${new Date().toISOString().slice(0, 10)}.json`;
  document.body.append(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  backupFeedback.textContent = translate("backupExported", { count: favoriteCurrencies.length, margins: calcMargins.length });
});

async function importFavoritesFromText(text) {
  let imported;
  try {
    imported = parseBackup(text);
  } catch {
    backupFeedback.textContent = translate("backupInvalid");
    return;
  }
  if (imported.favorites.length === 0 && imported.margins === null) {
    backupFeedback.textContent = translate("backupInvalid");
    return;
  }
  if (imported.favorites.length > 0) {
    const merged = [...new Set([...favoriteCurrencies, ...imported.favorites])];
    if (!(await persistPreference(FAVORITES_STORAGE_KEY, merged))) return;
    favoriteCurrencies = merged;
    renderCurrencyPickers();
  }
  // Los márgenes importados sustituyen a los actuales: es la lista que quieres llevarte a otro equipo.
  if (imported.margins !== null) {
    if (!(await persistPreference(MARGINS_STORAGE_KEY, imported.margins))) return;
    calcMargins = imported.margins;
    calcActiveMargin = null;
    renderMargins();
  }
  backupInput.value = "";
  backupFeedback.textContent = translate("backupImported", {
    count: imported.favorites.length,
    margins: imported.margins?.length ?? calcMargins.length
  });
}

async function importFavoritesFromFile(file) {
  if (!file) return;
  if (file.size > 100_000) {
    backupFeedback.textContent = translate("backupFileTooBig");
    return;
  }
  try {
    await importFavoritesFromText(await file.text());
  } catch {
    backupFeedback.textContent = translate("backupInvalid");
  }
}

backupImportButton.addEventListener("click", () => importFavoritesFromText(backupInput.value));

// El selector de archivos cierra el popup de Chrome, así que desde el popup se abre Divisa&Go en una pestaña.
const isTabView = location.hash === "#tab-backup";
if (isTabView) {
  document.documentElement.classList.add("is-tab");
  document.querySelector("#backup").open = true;
}
const backupDrop = document.querySelector("#backup-drop");
const backupFile = document.querySelector("#backup-file");
document.querySelector("#backup-pick").addEventListener("click", () => {
  if (!isTabView && globalThis.chrome?.tabs?.create && globalThis.chrome?.runtime?.getURL) {
    chrome.tabs.create({ url: chrome.runtime.getURL("sidepanel.html#tab-backup") });
    return;
  }
  backupFile.click();
});
backupFile.addEventListener("change", async () => {
  await importFavoritesFromFile(backupFile.files[0]);
  backupFile.value = "";
});
for (const type of ["dragenter", "dragover"]) {
  backupDrop.addEventListener(type, (event) => {
    event.preventDefault();
    backupDrop.classList.add("is-over");
  });
}
for (const type of ["dragleave", "drop"]) {
  backupDrop.addEventListener(type, () => backupDrop.classList.remove("is-over"));
}
backupDrop.addEventListener("drop", (event) => {
  event.preventDefault();
  void importFavoritesFromFile(event.dataTransfer?.files?.[0]);
});


// ---- Calculadora de divisas ----
function evaluateExpression(source) {
  const text = source.replace(/×/g, "*").replace(/÷/g, "/").replace(/[−–]/g, "-").replace(/,/g, ".").replace(/\s+/g, "");
  const tokens = text.match(/\d+\.?\d*|\.\d+|[()+\-*/%]/g) || [];
  if (tokens.length === 0 || tokens.join("") !== text) return NaN;
  let position = 0;
  const peek = () => tokens[position];
  function primary() {
    const token = tokens[position++];
    if (token === undefined) throw new Error("incompleto");
    let result;
    if (token === "(") {
      result = expression();
      if (tokens[position++] !== ")") throw new Error("paréntesis");
    } else if (token === "-") {
      result = { value: -primary().value, pct: false };
    } else if (token === "+") {
      return primary();
    } else if (/^[\d.]/.test(token)) {
      result = { value: Number(token), pct: false };
    } else {
      throw new Error("símbolo");
    }
    while (peek() === "%") {
      position += 1;
      result = { value: result.value / 100, pct: true };
    }
    return result;
  }
  function term() {
    let left = primary();
    while (peek() === "*" || peek() === "/") {
      const operator = tokens[position++];
      const right = primary();
      left = { value: operator === "*" ? left.value * right.value : left.value / right.value, pct: false };
    }
    return left;
  }
  function expression() {
    let left = term();
    while (peek() === "+" || peek() === "-") {
      const operator = tokens[position++];
      const right = term();
      // Como en una calculadora de bolsillo: 100 + 10% = 110
      const delta = right.pct ? left.value * right.value : right.value;
      left = { value: operator === "+" ? left.value + delta : left.value - delta, pct: false };
    }
    return left;
  }
  try {
    const result = expression();
    if (position !== tokens.length || !Number.isFinite(result.value)) return NaN;
    return Number(result.value.toPrecision(12));
  } catch {
    return NaN;
  }
}

// Tolera expresiones a medias: quita operadores sueltos al final y cierra paréntesis.
function evaluateLive(expression) {
  let text = expression;
  while (text) {
    const open = (text.match(/\(/g) || []).length - (text.match(/\)/g) || []).length;
    const value = evaluateExpression(text + ")".repeat(Math.max(0, open)));
    if (Number.isFinite(value)) return value;
    if (!/[+\-−×÷*/.(]$/.test(text)) return NaN;
    text = text.slice(0, -1);
  }
  return NaN;
}

function getExchangeRate(from, to) {
  if (from === to) return 1;
  const picked = pickedQuote(from, to);
  if (picked) return picked.quote.rate;
  const fromRate = rates && (from === "EUR" ? 1 : rates[from]?.rate);
  const toRate = rates && (to === "EUR" ? 1 : rates[to]?.rate);
  if (Number.isFinite(fromRate) && Number.isFinite(toRate)) return toRate / fromRate;
  return getFallbackQuote(from, to)?.quote.rate ?? null;
}

const calcOverlay = document.querySelector("#calc-overlay");
const calcOpenButton = document.querySelector("#calc-open");
const calcExpressionElement = document.querySelector("#calc-expression");
const calcResultElement = document.querySelector("#calc-result");
const calcFromElement = document.querySelector("#calc-from");
const calcToElement = document.querySelector("#calc-to");
const calcPairElement = document.querySelector("#calc-pair");
const calcUseButton = document.querySelector("#calc-use");
let calcExpression = "";
let calcFresh = false;
// Posición del cursor en la expresión; Infinity = al final.
let calcCaret = Infinity;

function formatPlainNumber(value) {
  return new Intl.NumberFormat(currentLanguage, { maximumSignificantDigits: 12 }).format(value);
}

const calcHint = document.querySelector("#calc-hint");
let calcHintTimeout = 0;

function showCalcHint(text, flash = false) {
  window.clearTimeout(calcHintTimeout);
  calcHint.textContent = text;
  calcHint.classList.toggle("is-flash", flash);
  if (flash) {
    calcHintTimeout = window.setTimeout(() => {
      calcHint.textContent = translate("calcHint");
      calcHint.classList.remove("is-flash");
    }, 2200);
  }
}

async function copyCalcFigure(text) {
  if (!text || text === "—") return;
  try {
    await navigator.clipboard.writeText(text);
    showCalcHint(translate("calcCopied", { value: text }), true);
    celebrate(document.querySelector("#calc-display"));
    return true;
  } catch (error) {
    console.error("No se pudo copiar la cifra de la calculadora:", error);
    showCalcHint(translate("calcCopyFailed"), true);
    return false;
  }
}

function renderCalculator() {
  const from = fromSelect.value;
  const to = toSelect.value;
  const value = evaluateLive(calcExpression);
  calcExpressionElement.value = calcExpression;
  const caret = Math.min(calcCaret, calcExpression.length);
  calcExpressionElement.setSelectionRange(caret, caret);
  if (!calcHint.classList.contains("is-flash")) calcHint.textContent = translate("calcHint");
  const pickedForCalc = pickedQuote(from, to);
  calcPairElement.textContent = `${from} → ${to}${pickedForCalc ? ` · ${providerLabel(pickedForCalc.provider)}` : ""}`;
  renderSourcePickers();
  const valid = Number.isFinite(value) && value >= 0;
  renderReverse();
  calcUseButton.disabled = !valid;
  document.querySelector("#calc-share").disabled = !valid;
  if (!Number.isFinite(value)) {
    calcResultElement.textContent = calcExpression ? translate("calcInvalid") : "";
    calcFromElement.textContent = "—";
    calcToElement.textContent = "—";
    return;
  }
  calcResultElement.textContent = `= ${formatPlainNumber(value)}`;
  calcFromElement.textContent = formatAmount(value, from);
  const rate = getExchangeRate(from, to);
  calcToElement.textContent = rate === null ? translate("waitingRates") : formatAmount(value * rate, to);
}

// ---- Márgenes (porcentajes sobre precio neto) ----
let calcMarginBase = null;
let calcActiveMargin = null;

function normalizeMargins(list) {
  const clean = list
    .map(Number)
    .filter((value) => Number.isFinite(value) && value !== 0 && value > -100 && value <= 1000)
    .map((value) => Number(value.toFixed(2)));
  return [...new Set(clean)].sort((a, b) => a - b).slice(0, MAX_MARGINS);
}

function formatMargin(value) {
  return `${value > 0 ? "+" : "−"}${Math.abs(value)}%`;
}

function renderMargins() {
  const list = document.querySelector("#calc-margin-list");
  const editing = document.querySelector("#calc-gear").getAttribute("aria-pressed") === "true";
  list.replaceChildren();
  if (calcMargins.length === 0) {
    const empty = document.createElement("span");
    empty.className = "calc-margin-empty";
    empty.textContent = translate("marginsEmpty");
    list.append(empty);
    return;
  }
  for (const value of calcMargins) {
    const chip = document.createElement("span");
    chip.className = "calc-margin-chip";
    chip.classList.toggle("is-negative", value < 0);
    const apply = document.createElement("button");
    apply.type = "button";
    apply.textContent = formatMargin(value);
    apply.dataset.margin = String(value);
    apply.setAttribute("aria-pressed", String(calcActiveMargin === value));
    chip.append(apply);
    if (editing) {
      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "calc-margin-remove";
      remove.textContent = "✕";
      remove.dataset.remove = String(value);
      remove.setAttribute("aria-label", translate("marginsRemove", { value: formatMargin(value) }));
      chip.append(remove);
    }
    list.append(chip);
  }
}

async function saveMargins(next) {
  const previous = calcMargins;
  calcMargins = next;
  if (calcActiveMargin !== null && !next.includes(calcActiveMargin)) calcActiveMargin = null;
  renderMargins();
  if (!(await persistPreference(MARGINS_STORAGE_KEY, next))) {
    calcMargins = previous;
    renderMargins();
  }
}

function applyMargin(value) {
  if (calcActiveMargin === value) {
    // Segundo toque: deshace el margen y vuelve al precio neto.
    calcExpression = calcMarginBase ?? calcExpression;
    calcCaret = Infinity;
    calcMarginBase = null;
    calcActiveMargin = null;
    calcFresh = false;
    renderCalculator();
    renderMargins();
    void persistSessionState();
    return;
  }
  let base = calcMarginBase ?? calcExpression;
  if (!Number.isFinite(evaluateLive(base)) || evaluateLive(base) <= 0) {
    const reverseNet = document.querySelector("#calc-reverse").hidden
      ? NaN
      : parseAmount(document.querySelector("#calc-reverse-net").value);
    if (reverseNet > 0) base = amountText(reverseNet);
  }
  const net = evaluateLive(base);
  if (!Number.isFinite(net) || net <= 0) {
    showCalcHint(translate("marginsNeedAmount"), true);
    return;
  }
  const wrapped = /^[\d.]+$/.test(base) ? base : `(${base})`;
  calcMarginBase = base;
  calcActiveMargin = value;
  calcExpression = `${wrapped}${value > 0 ? "+" : "−"}${Math.abs(value)}%`;
  calcCaret = Infinity;
  calcFresh = false;
  renderCalculator();
  renderMargins();
  popElement(document.querySelector('#calc-margin-list button[aria-pressed="true"]'));
  celebrate(document.querySelector("#calc-display"));
  const total = evaluateLive(calcExpression);
  showCalcHint(translate("marginsApplied", {
    margin: formatMargin(value),
    net: formatPlainNumber(net),
    diff: formatPlainNumber(Math.abs(total - net)),
    total: formatPlainNumber(total)
  }), true);
  void persistSessionState();
}

// ---- Calcular al revés: del precio final al margen ----
let reverseMarkup = null;

function formatPercent(value) {
  return `${new Intl.NumberFormat(currentLanguage, { maximumFractionDigits: 2, signDisplay: "exceptZero" }).format(value)}%`;
}

function renderReverse() {
  const panel = document.querySelector("#calc-reverse");
  if (panel.hidden) return;
  const out = document.querySelector("#calc-reverse-out");
  const save = document.querySelector("#calc-reverse-save");
  const net = parseAmount(document.querySelector("#calc-reverse-net").value);
  const final = evaluateLive(calcExpression);
  out.replaceChildren();
  reverseMarkup = null;
  if (!(net > 0) || !Number.isFinite(final) || final <= 0) {
    out.textContent = translate(net > 0 ? "reverseNeedFinal" : "reverseNeedNet");
    save.hidden = true;
    return;
  }
  const code = fromSelect.value;
  const markup = ((final - net) / net) * 100;
  const margin = ((final - net) / final) * 100;
  const lines = [
    ["reverseMarkup", formatPercent(markup), true],
    ["reverseMargin", formatPercent(margin), false],
    ["reverseProfit", formatAmount(final - net, code), false]
  ];
  for (const [key, value, strong] of lines) {
    const row = document.createElement("span");
    const [before, after] = translate(key, { value: "\u0000" }).split("\u0000");
    const figure = document.createElement(strong ? "strong" : "b");
    figure.textContent = value;
    row.append(before, figure, after ?? "");
    row.classList.toggle("is-loss", final < net);
    out.append(row);
  }
  const rounded = Number(markup.toFixed(2));
  if (rounded !== 0 && rounded > -100 && rounded <= 1000) {
    reverseMarkup = rounded;
    save.textContent = translate("reverseSave", { value: formatMargin(rounded) });
    save.hidden = calcMargins.includes(rounded);
  } else {
    save.hidden = true;
  }
}

function pressCalcKey(key) {
  if (calcActiveMargin !== null || calcMarginBase !== null) {
    calcActiveMargin = null;
    calcMarginBase = null;
    renderMargins();
  }
  const isOperator = /^[+\-−×÷*/]$/.test(key);
  const length = calcExpression.length;
  let start = Math.min(calcExpressionElement.selectionStart ?? length, length);
  let end = Math.min(calcExpressionElement.selectionEnd ?? start, length);
  if (key === "C") {
    calcExpression = "";
    calcFresh = false;
    start = 0;
  } else if (key === "⌫" || key === "⌦") {
    if (calcFresh) {
      calcExpression = "";
      start = 0;
    } else {
      if (start === end) {
        if (key === "⌫") start = Math.max(0, start - 1);
        else end = Math.min(length, end + 1);
      }
      calcExpression = calcExpression.slice(0, start) + calcExpression.slice(end);
    }
    calcFresh = false;
  } else if (key === "=") {
    const value = evaluateLive(calcExpression);
    if (Number.isFinite(value)) {
      calcExpression = String(value);
      calcFresh = true;
      start = Infinity;
    }
  } else {
    if (calcFresh) {
      if (isOperator || key === "%") start = end = length;
      else {
        calcExpression = "";
        start = end = 0;
      }
    }
    calcFresh = false;
    const symbol = { "*": "×", "/": "÷", "-": "−" }[key] || key;
    let before = calcExpression.slice(0, start);
    const after = calcExpression.slice(end);
    if (isOperator && /[+\-−×÷]$/.test(before)) before = before.slice(0, -1);
    if (!(isOperator && before === "" && symbol !== "−")) {
      calcExpression = before + symbol + after;
      start = before.length + symbol.length;
    }
  }
  calcCaret = start;
  renderCalculator();
  void persistSessionState();
}

function openCalculator() {
  calcActiveMargin = null;
  calcMarginBase = null;
  renderMargins();
  const current = parseAmount(amountInput.value);
  calcExpression = Number.isFinite(current) ? String(current) : "";
  calcFresh = calcExpression !== "";
  calcCaret = Infinity;
  selectTab("calc");
}

function showRestoredCalculator(expression, fresh) {
  calcExpression = expression;
  calcFresh = fresh;
  calcCaret = Infinity;
  renderCalculator();
}

function closeCalculator() {
  selectTab("fx");
  amountInput.focus({ preventScroll: true });
}

calcOpenButton.addEventListener("click", openCalculator);
document.querySelector("#calc-close").addEventListener("click", closeCalculator);
function copyCalcResult() {
  const value = evaluateLive(calcExpression);
  if (Number.isFinite(value)) void copyCalcFigure(String(value));
}
calcResultElement.addEventListener("click", copyCalcResult);
document.querySelector("#calc-copy-value").addEventListener("click", copyCalcResult);
// Mover el cursor con el ratón o las flechas: se recuerda para insertar ahí.
for (const type of ["click", "keyup", "select", "focus"]) {
  calcExpressionElement.addEventListener(type, () => {
    calcCaret = calcExpressionElement.selectionStart ?? Infinity;
  });
}
calcExpressionElement.addEventListener("paste", (event) => {
  event.preventDefault();
  const text = (event.clipboardData?.getData("text") ?? "").slice(0, 80);
  const pastedAmount = /^[\d.,\s'‘’ʼʻ´`′ʹ_\u00a0\u202f\u2009\u066b\u066c\uff0c\uff0e\u060c\u00b7]+$/.test(text) ? parseAmount(text) : NaN;
  if (Number.isFinite(pastedAmount)) {
    for (const char of amountText(pastedAmount)) pressCalcKey(char);
    return;
  }
  for (const char of text.replace(/\s+/g, "")) {
    if (/^[0-9.+\-−×÷*/%()]$/.test(char)) pressCalcKey(char);
    else if (char === ",") pressCalcKey(".");
  }
});
calcFromElement.addEventListener("click", () => copyCalcFigure(calcFromElement.textContent));
calcToElement.addEventListener("click", () => copyCalcFigure(calcToElement.textContent));
document.querySelector("#calc-keys").addEventListener("click", (event) => {
  const button = event.target.closest("button[data-key]");
  if (button) {
    pressCalcKey(button.dataset.key);
    calcExpressionElement.focus({ preventScroll: true });
  }
});
document.querySelector("#calc-swap").addEventListener("click", () => {
  swapButton.click();
  renderCalculator();
});
// Texto para el cliente: solo el precio final, sin neto ni margen.
document.querySelector("#calc-share").addEventListener("click", () => {
  const from = calcFromElement.textContent;
  const to = calcToElement.textContent;
  if (!from || from === "—") return;
  const showConverted = fromSelect.value !== toSelect.value && to && to !== "—" && to !== translate("waitingRates");
  const text = translate(showConverted ? "calcShareText" : "calcShareTextSingle", { from, to });
  void copyCalcFigure(text).then((copied) => {
    if (copied) {
      showCalcHint(translate("calcShareCopied"), true);
      celebrate(document.querySelector("#calc-share"));
    }
  });
});
calcUseButton.addEventListener("click", () => {
  const value = evaluateLive(calcExpression);
  if (!Number.isFinite(value) || value < 0) return;
  amountInput.value = amountText(value);
  amountInput.dispatchEvent(new Event("input", { bubbles: true }));
  closeCalculator();
});
document.querySelector("#calc-margin-list").addEventListener("click", (event) => {
  const apply = event.target.closest("button[data-margin]");
  if (apply) return applyMargin(Number(apply.dataset.margin));
  const remove = event.target.closest("button[data-remove]");
  if (remove) void saveMargins(calcMargins.filter((value) => value !== Number(remove.dataset.remove)));
});
document.querySelector("#calc-reverse-toggle").addEventListener("click", () => {
  const toggle = document.querySelector("#calc-reverse-toggle");
  const on = toggle.getAttribute("aria-pressed") !== "true";
  toggle.setAttribute("aria-pressed", String(on));
  document.querySelector("#calc-reverse").hidden = !on;
  renderCalculator();
  if (on) document.querySelector("#calc-reverse-net").focus();
});
document.querySelector("#calc-reverse-net").addEventListener("input", () => {
  sanitizeAmountField(document.querySelector("#calc-reverse-net"));
  renderReverse();
});
document.querySelector("#calc-reverse-save").addEventListener("click", async () => {
  if (reverseMarkup === null) return;
  const added = reverseMarkup;
  await saveMargins(normalizeMargins([...calcMargins, added]));
  showCalcHint(translate("reverseSaved", { value: formatMargin(added) }), true);
  renderReverse();
});
document.querySelector("#calc-gear").addEventListener("click", () => {
  const gear = document.querySelector("#calc-gear");
  const editing = gear.getAttribute("aria-pressed") !== "true";
  gear.setAttribute("aria-pressed", String(editing));
  document.querySelector("#calc-margin-form").hidden = !editing;
  renderMargins();
  if (editing) document.querySelector("#calc-margin-input").focus();
});
document.querySelector("#calc-margin-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const input = document.querySelector("#calc-margin-input");
  const value = Number(input.value);
  const next = normalizeMargins([...calcMargins, value]);
  if (input.value.trim() === "" || !next.includes(Number(value.toFixed(2)))) {
    showCalcHint(translate(calcMargins.length >= MAX_MARGINS && input.value.trim() !== "" ? "marginsFull" : "marginsInvalid"), true);
    return;
  }
  input.value = "";
  void saveMargins(next);
});
document.querySelector("#calc-margin-reset").addEventListener("click", () => {
  void saveMargins([...DEFAULT_MARGINS]);
});
calcOverlay.addEventListener("keydown", (event) => {
  if (event.target.id === "calc-margin-input" || event.target.id === "calc-reverse-net") {
    if (event.key === "Escape") calcExpressionElement.focus({ preventScroll: true });
    return;
  }
  const hasSelection = calcExpressionElement.selectionStart !== calcExpressionElement.selectionEnd;
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "c" && hasSelection) {
    return;
  }
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "c") {
    const value = evaluateLive(calcExpression);
    if (Number.isFinite(value)) {
      event.preventDefault();
      void copyCalcFigure(String(value));
    }
  } else if (event.key === "Escape") {
    calcExpressionElement.focus({ preventScroll: true });
  } else if (/^[0-9.+\-*/%]$/.test(event.key) && !event.ctrlKey && !event.metaKey) {
    event.preventDefault();
    pressCalcKey(event.key);
  } else if (event.key === ",") {
    event.preventDefault();
    pressCalcKey(".");
  } else if (event.key === "x" || event.key === "X") {
    event.preventDefault();
    pressCalcKey("×");
  } else if (event.key === "(" || event.key === ")") {
    event.preventDefault();
    pressCalcKey(event.key);
  } else if (event.key === "Enter" && document.activeElement?.tagName !== "BUTTON") {
    event.preventDefault();
    pressCalcKey("=");
  } else if (event.key === "Backspace") {
    event.preventDefault();
    pressCalcKey("⌫");
  } else if (event.key === "Delete") {
    event.preventDefault();
    pressCalcKey("⌦");
  }
});

// ---- Metales y materias primas ----
const OUNCE_GRAMS = 31.1034768;
const METALS_TTL_MS = 15 * 60 * 1000;
const METAL_ITEMS = [
  { id: "gold", name: "metalGold", symbol: "XAU", logo: "Au", color: "#d4a017", kind: "metal", tv: "XAUUSD" },
  { id: "silver", name: "metalSilver", symbol: "XAG", logo: "Ag", color: "#8e9aa8", kind: "metal", tv: "XAGUSD" },
  { id: "platinum", name: "metalPlatinum", symbol: "XPT", logo: "Pt", color: "#6f8296", kind: "metal", tv: "XPTUSD" },
  { id: "palladium", name: "metalPalladium", symbol: "XPD", logo: "Pd", color: "#a8a089", kind: "metal", tv: "XPDUSD" },
  { id: "copper", name: "metalCopper", symbol: "Cu", color: "#b87333", kind: "commodity", unit: "lb", tv: "COMEX-HG1%21" },
  { id: "wti", name: "metalWti", symbol: "WTI", color: "#4d5d6c", kind: "commodity", unit: "bbl", tv: "NYMEX-CL1%21" },
  { id: "brent", name: "metalBrent", symbol: "BRT", color: "#2c7a7b", kind: "commodity", unit: "bbl", tv: "ICEEUR-BRN1%21" }
];
const metalsAmount = document.querySelector("#metals-amount");
const metalsFiat = document.querySelector("#metals-fiat");
const metalsList = document.querySelector("#metals-list");
const metalsStatus = document.querySelector("#metals-status");
const metalsRefreshButton = document.querySelector("#metals-refresh");
const metalsUnits = document.querySelector("#metals-units");
let metalsUnit = "oz";
let metalsFiatPending = "";
let metalsFiatLanguage = "";
let metalsPrices = {};
let metalsFetchedAt = 0;
let metalsLoading = false;
let metalsFailed = false;

function applyMetalsPreferences(prefs, cache) {
  if (prefs && typeof prefs === "object") {
    if (["oz", "g", "kg"].includes(prefs.unit)) metalsUnit = prefs.unit;
    if (typeof prefs.fiat === "string" && /^[A-Z]{3}$/.test(prefs.fiat)) metalsFiatPending = prefs.fiat;
    if (typeof prefs.amount === "string" && prefs.amount.length <= 40) metalsAmount.value = prefs.amount;
  }
  if (cache && typeof cache === "object" && cache.prices && Number.isFinite(cache.fetchedAt) && Date.now() - cache.fetchedAt < QUOTE_STALE_MAX_MS) {
    for (const item of METAL_ITEMS) {
      const entry = cache.prices[item.id];
      if (entry && Number.isFinite(entry.usd) && entry.usd > 0) {
        metalsPrices[item.id] = { usd: entry.usd, mismatch: entry.mismatch === true };
      }
    }
    metalsFetchedAt = cache.fetchedAt;
  }
}

function saveMetalsPreferences() {
  void persistPreference(METALS_PREFS_STORAGE_KEY, {
    unit: metalsUnit,
    fiat: metalsFiat.value || metalsFiatPending || "USD",
    amount: metalsAmount.value.slice(0, 40)
  });
}

function populateMetalsFiat() {
  if (metalsFiatLanguage === currentLanguage && metalsFiat.options.length) return;
  const previous = metalsFiat.value || metalsFiatPending || toSelect.value || "USD";
  const fragment = document.createDocumentFragment();
  for (const currency of CURRENCIES) {
    if (rates && currency.code !== "EUR" && !rates[currency.code]) continue;
    const option = document.createElement("option");
    option.value = currency.code;
    option.textContent = `${currency.code} · ${currency.name}`;
    fragment.append(option);
  }
  metalsFiat.replaceChildren(fragment);
  metalsFiat.value = [...metalsFiat.options].some((option) => option.value === previous) ? previous : "USD";
  metalsFiatLanguage = currentLanguage;
}

// Lee el precio de TradingView (JSON de su página) y se detiene en cuanto aparece.
async function fetchTradingViewPrice(slug, signal) {
  const response = await fetch(`https://www.tradingview.com/symbols/${slug}/`, { cache: "no-store", credentials: "omit", signal });
  if (!response.ok) throw new Error(`TradingView respondió con el código ${response.status}.`);
  if (!response.body) throw new Error("TradingView no devolvió contenido legible.");
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let html = "";
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (value) html += decoder.decode(value, { stream: true });
      const match = html.match(/"trade":\{"price":([0-9.]+(?:[eE][+-]?\d+)?)\}/);
      if (match) {
        const before = html.slice(0, match.index);
        const currency = before.slice(before.lastIndexOf('"currency_code":"') + 17, before.lastIndexOf('"currency_code":"') + 20);
        const price = Number(match[1]);
        if (currency !== "USD" || !Number.isFinite(price) || price <= 0) throw new Error(`TradingView devolvió un precio no válido para ${slug}.`);
        return price;
      }
      if (done || html.length > 2_000_000) throw new Error(`No se encontró el precio de ${slug} en TradingView.`);
    }
  } finally {
    reader.cancel().catch(() => {});
  }
}

// Metales: Xe y TradingView (si coinciden se promedian); materias primas: solo TradingView (futuros).
async function fetchMetalItem(item, signal) {
  const tasks = [withRetry(() => fetchTradingViewPrice(item.tv, signal), signal).then((usd) => ({ source: "tradingview", usd }))];
  if (item.kind === "metal") {
    tasks.push(withRetry(() => fetchThirdPartyQuote("xe", item.symbol, "USD", signal), signal).then((quote) => ({ source: "xe", usd: quote.rate })));
  }
  const found = (await Promise.allSettled(tasks)).filter((result) => result.status === "fulfilled").map((result) => result.value);
  if (found.length === 0) throw new Error(`Sin precio para ${item.id}.`);
  if (found.length === 1) return { usd: found[0].usd, mismatch: false };
  const [first, second] = found;
  const gap = Math.abs(first.usd - second.usd) / ((first.usd + second.usd) / 2);
  return gap <= 0.03
    ? { usd: (first.usd + second.usd) / 2, mismatch: false }
    : { usd: found.find((entry) => entry.source === "tradingview").usd, mismatch: true };
}

async function refreshMetals(force = false) {
  if (metalsLoading) return;
  if (!force && Object.keys(metalsPrices).length === METAL_ITEMS.length && Date.now() - metalsFetchedAt < METALS_TTL_MS) {
    renderMetals();
    return;
  }
  metalsLoading = true;
  metalsFailed = false;
  renderMetals();
  const controller = new AbortController();
  const timeoutId = window.setTimeout(() => controller.abort(), 30000);
  let succeeded = 0;
  try {
    const queue = [...METAL_ITEMS];
    const worker = async () => {
      while (queue.length) {
        const item = queue.shift();
        try {
          metalsPrices[item.id] = await fetchMetalItem(item, controller.signal);
          succeeded += 1;
          renderMetals();
        } catch (error) {
          console.error(`No se pudo consultar ${item.id}:`, error);
        }
      }
    };
    await Promise.all([worker(), worker(), worker()]);
    if (succeeded > 0) {
      metalsFetchedAt = Date.now();
      void persistPreference(METALS_CACHE_STORAGE_KEY, { prices: metalsPrices, fetchedAt: metalsFetchedAt });
    } else {
      metalsFailed = true;
    }
  } finally {
    window.clearTimeout(timeoutId);
    metalsLoading = false;
  }
  renderMetals();
}

function renderMetals() {
  populateMetalsFiat();
  const fiat = metalsFiat.value || "USD";
  const factor = usdToFiatFactor(fiat);
  const amount = parseAmount(metalsAmount.value);
  const amountValid = metalsAmount.value.trim() !== "" && Number.isFinite(amount) && amount >= 0;
  for (const button of metalsUnits.querySelectorAll("button")) {
    button.setAttribute("aria-pressed", String(button.dataset.unit === metalsUnit));
  }
  metalsRefreshButton.disabled = metalsLoading;
  metalsRefreshButton.classList.toggle("is-loading", metalsLoading);
  metalsRefreshButton.setAttribute("aria-busy", String(metalsLoading));

  const rows = METAL_ITEMS.map((item) => {
    const entry = metalsPrices[item.id];
    let unitLabel = item.unit || metalsUnit;
    let unitPrice = null;
    if (entry && factor !== null) {
      const perBase = entry.usd * factor; // por onza troy, libra o barril
      unitPrice = item.kind === "metal"
        ? (metalsUnit === "oz" ? perBase : metalsUnit === "g" ? perBase / OUNCE_GRAMS : (perBase / OUNCE_GRAMS) * 1000)
        : perBase;
    }
    let main = "—";
    let sub = `${item.symbol} · ${unitLabel}`;
    if (unitPrice !== null && amountValid) {
      main = formatFiatPrice(amount * unitPrice, fiat);
      sub = `${item.symbol} · 1 ${unitLabel} = ${formatFiatPrice(unitPrice, fiat)}`;
    } else if (unitPrice !== null) {
      main = translate("quoteInvalid");
    }
    const row = document.createElement("div");
    row.className = "crypto-row";
    const logo = document.createElement("span");
    logo.className = "crypto-logo";
    logo.style.background = item.color;
    logo.textContent = item.logo || item.symbol.slice(0, 2);
    logo.setAttribute("aria-hidden", "true");
    const name = document.createElement("span");
    name.className = "crypto-name";
    const title = document.createElement("strong");
    title.textContent = translate(item.name);
    const small = document.createElement("small");
    small.textContent = sub;
    name.append(title, small);
    const value = document.createElement("span");
    value.className = "crypto-value";
    const total = document.createElement("strong");
    total.textContent = main;
    const note = document.createElement("small");
    if (entry?.mismatch) {
      note.textContent = "⚠";
      note.title = translate("metalsMismatch");
      note.className = "is-warning";
    }
    value.append(total, note);
    row.append(logo, name, value);
    return row;
  });
  metalsList.replaceChildren(...rows);

  if (metalsLoading && !metalsFetchedAt) metalsStatus.textContent = translate("metalsLoading");
  else if (metalsFailed && !metalsFetchedAt) metalsStatus.textContent = translate("metalsError");
  else if (metalsFetchedAt && factor === null) metalsStatus.textContent = translate("cryptoWaitingRates");
  else if (metalsFetchedAt) {
    const stale = Date.now() - metalsFetchedAt > METALS_TTL_MS * 2;
    metalsStatus.textContent = translate(stale ? "metalsStale" : "metalsUpdated", { time: formatDateTime(metalsFetchedAt) });
    if (Object.values(metalsPrices).some((entry) => entry.mismatch)) {
      metalsStatus.textContent += ` · ⚠ ${translate("metalsMismatch")}`;
    }
  } else metalsStatus.textContent = "";
}

metalsAmount.addEventListener("input", () => {
  sanitizeAmountField(metalsAmount);
  renderMetals();
  saveMetalsPreferences();
});
metalsFiat.addEventListener("change", () => {
  renderMetals();
  saveMetalsPreferences();
});
metalsUnits.addEventListener("click", (event) => {
  const button = event.target.closest("button[data-unit]");
  if (!button) return;
  metalsUnit = button.dataset.unit;
  renderMetals();
  saveMetalsPreferences();
});
metalsRefreshButton.addEventListener("click", () => refreshMetals(true));

// ---- Sección Cripto ----
const CRYPTO_COINS = [
  { id: "bitcoin", symbol: "BTC", name: "Bitcoin", color: "#f7931a" },
  { id: "ethereum", symbol: "ETH", name: "Ethereum", color: "#627eea" },
  { id: "tether", symbol: "USDT", name: "Tether", color: "#26a17b" },
  { id: "binancecoin", symbol: "BNB", name: "BNB", color: "#f3ba2f" },
  { id: "solana", symbol: "SOL", name: "Solana", color: "#9945ff" },
  { id: "ripple", symbol: "XRP", name: "XRP", color: "#23292f" },
  { id: "usd-coin", symbol: "USDC", name: "USD Coin", color: "#2775ca" },
  { id: "dogecoin", symbol: "DOGE", name: "Dogecoin", color: "#c2a633" },
  { id: "cardano", symbol: "ADA", name: "Cardano", color: "#0033ad" },
  { id: "tron", symbol: "TRX", name: "TRON", color: "#eb0029" },
  { id: "avalanche-2", symbol: "AVAX", name: "Avalanche", color: "#e84142" },
  { id: "litecoin", symbol: "LTC", name: "Litecoin", color: "#345d9d" }
];
const CRYPTO_API_URL = "https://api.coingecko.com/api/v3/simple/price";
const CRYPTO_CACHE_TTL_MS = 5 * 60 * 1000;
const tabButtons = document.querySelectorAll("[data-tab]");
const panelFx = document.querySelector("#panel-fx");
const panelCrypto = document.querySelector("#panel-crypto");
const panelMetals = document.querySelector("#panel-metals");
const cryptoList = document.querySelector("#crypto-list");
const cryptoAmount = document.querySelector("#crypto-amount");
cryptoAmount.addEventListener("input", () => sanitizeAmountField(cryptoAmount));
const cryptoFiat = document.querySelector("#crypto-fiat");
const cryptoMode = document.querySelector("#crypto-mode");
const cryptoRefreshButton = document.querySelector("#crypto-refresh");
const cryptoStatus = document.querySelector("#crypto-status");
let cryptoPrices = null;
let cryptoFetchedAt = 0;
let cryptoInverted = false;
let cryptoLoading = false;
let cryptoFailed = false;
let cryptoFiatLanguage = "";

function applyCachedCrypto(cache) {
  if (!cache || typeof cache !== "object" || !cache.prices || !Number.isFinite(cache.fetchedAt)) return;
  if (Date.now() - cache.fetchedAt >= CRYPTO_CACHE_TTL_MS || cache.fetchedAt > Date.now()) return;
  const prices = {};
  for (const coin of CRYPTO_COINS) {
    const entry = cache.prices[coin.id];
    if (entry && Number.isFinite(entry.usd) && entry.usd > 0) {
      prices[coin.id] = { usd: entry.usd, change: Number.isFinite(entry.change) ? entry.change : null };
    }
  }
  if (Object.keys(prices).length === 0) return;
  cryptoPrices = prices;
  cryptoFetchedAt = cache.fetchedAt;
}

function populateCryptoFiat() {
  if (cryptoFiatLanguage === currentLanguage && cryptoFiat.options.length) return;
  const previous = cryptoFiat.value || cryptoFiatPending || toSelect.value || "USD";
  const fragment = document.createDocumentFragment();
  for (const currency of CURRENCIES) {
    if (rates && currency.code !== "EUR" && !rates[currency.code]) continue;
    const option = document.createElement("option");
    option.value = currency.code;
    option.textContent = `${currency.code} · ${currency.name}`;
    fragment.append(option);
  }
  cryptoFiat.replaceChildren(fragment);
  cryptoFiat.value = [...cryptoFiat.options].some((option) => option.value === previous) ? previous : "USD";
  cryptoFiatLanguage = currentLanguage;
}

function usdToFiatFactor(fiat) {
  if (fiat === "USD") return 1;
  const usdRate = rates?.USD?.rate;
  const fiatRate = fiat === "EUR" ? 1 : rates?.[fiat]?.rate;
  return Number.isFinite(usdRate) && Number.isFinite(fiatRate) ? fiatRate / usdRate : null;
}

function formatFiatPrice(value, fiat) {
  return new Intl.NumberFormat(currentLanguage, {
    style: "currency",
    currency: fiat,
    minimumFractionDigits: value < 1 ? 2 : undefined,
    maximumFractionDigits: value < 1 ? 4 : 2
  }).format(value);
}

function renderCrypto() {
  populateCryptoFiat();
  const fiat = cryptoFiat.value || "USD";
  const factor = usdToFiatFactor(fiat);
  const amount = parseAmount(cryptoAmount.value);
  const amountValid = cryptoAmount.value.trim() !== "" && Number.isFinite(amount) && amount >= 0;
  cryptoMode.textContent = translate(cryptoInverted ? "cryptoModeToCoin" : "cryptoModeToFiat");
  const busy = cryptoLoading || cryptoSourcesLoading;
  cryptoRefreshButton.disabled = busy;
  cryptoRefreshButton.classList.toggle("is-loading", busy);
  cryptoRefreshButton.setAttribute("aria-busy", String(busy));

  const rows = CRYPTO_COINS.map((coin) => {
    const price = cryptoPrices?.[coin.id];
    const unit = price && factor !== null ? price.usd * factor : null;
    let main = "—";
    let sub = coin.symbol;
    if (unit !== null && amountValid) {
      if (cryptoInverted) {
        main = `${new Intl.NumberFormat(currentLanguage, { maximumSignificantDigits: 6 }).format(amount / unit)} ${coin.symbol}`;
        sub = `1 ${coin.symbol} = ${formatFiatPrice(unit, fiat)}`;
      } else {
        main = formatFiatPrice(amount * unit, fiat);
        sub = amount === 1 ? coin.symbol : `${coin.symbol} · 1 = ${formatFiatPrice(unit, fiat)}`;
      }
    } else if (unit !== null) {
      main = translate("quoteInvalid");
    }
    const change = price?.change;
    const row = document.createElement("button");
    row.type = "button";
    row.className = "crypto-row";
    row.classList.toggle("is-selected", coin.id === cryptoSelectedId);
    row.setAttribute("aria-pressed", String(coin.id === cryptoSelectedId));
    row.addEventListener("click", () => {
      cryptoSelectedId = coin.id;
      renderCrypto();
      void refreshCryptoSources();
      void persistSessionState();
    });
    const logo = document.createElement("span");
    logo.className = "crypto-logo";
    logo.style.background = coin.color;
    logo.textContent = coin.symbol.slice(0, 1);
    logo.setAttribute("aria-hidden", "true");
    const name = document.createElement("span");
    name.className = "crypto-name";
    const title = document.createElement("strong");
    title.textContent = coin.name;
    const small = document.createElement("small");
    small.textContent = sub;
    name.append(title, small);
    const value = document.createElement("span");
    value.className = "crypto-value";
    const amountText = document.createElement("strong");
    amountText.textContent = main;
    const changeText = document.createElement("small");
    if (Number.isFinite(change)) {
      changeText.textContent = `${change >= 0 ? "▲" : "▼"} ${Math.abs(change).toFixed(2)}%`;
      changeText.className = change >= 0 ? "is-up" : "is-down";
    }
    value.append(amountText, changeText);
    row.append(logo, name, value);
    return row;
  });
  cryptoList.replaceChildren(...rows);
  renderCryptoSources();

  if (cryptoLoading && !cryptoPrices) cryptoStatus.textContent = translate("cryptoLoading");
  else if (cryptoFailed && !cryptoPrices) cryptoStatus.textContent = translate("cryptoError");
  else if (cryptoPrices && factor === null) cryptoStatus.textContent = translate("cryptoWaitingRates");
  else if (cryptoPrices) {
    cryptoStatus.textContent = translate("cryptoUpdated", {
      time: new Intl.DateTimeFormat(currentLanguage, { hour: "2-digit", minute: "2-digit" }).format(new Date(cryptoFetchedAt))
    }) + (cryptoFailed ? ` · ${translate("cryptoError")}` : "");
  } else cryptoStatus.textContent = "";
}

async function refreshCrypto(force = false) {
  if (cryptoLoading) return;
  if (!force && cryptoPrices && Date.now() - cryptoFetchedAt < CRYPTO_CACHE_TTL_MS) {
    renderCrypto();
    return;
  }
  cryptoLoading = true;
  cryptoFailed = false;
  renderCrypto();
  const controller = new AbortController();
  const timeoutId = window.setTimeout(() => controller.abort(), 10000);
  try {
    const url = new URL(CRYPTO_API_URL);
    url.searchParams.set("ids", CRYPTO_COINS.map((coin) => coin.id).join(","));
    url.searchParams.set("vs_currencies", "usd");
    url.searchParams.set("include_24hr_change", "true");
    const response = await fetch(url, { signal: controller.signal, credentials: "omit" });
    if (!response.ok) throw new Error(`CoinGecko respondió con el código ${response.status}.`);
    const data = await response.json();
    const prices = {};
    for (const coin of CRYPTO_COINS) {
      const entry = data?.[coin.id];
      if (entry && Number.isFinite(entry.usd) && entry.usd > 0) {
        prices[coin.id] = { usd: entry.usd, change: Number.isFinite(entry.usd_24h_change) ? entry.usd_24h_change : null };
      }
    }
    if (Object.keys(prices).length === 0) throw new Error("CoinGecko no devolvió precios válidos.");
    cryptoPrices = prices;
    cryptoFetchedAt = Date.now();
    void persistPreference(CRYPTO_CACHE_STORAGE_KEY, { prices, fetchedAt: cryptoFetchedAt });
  } catch (error) {
    console.error("No se pudieron cargar los precios cripto:", error);
    cryptoFailed = true;
  } finally {
    window.clearTimeout(timeoutId);
    cryptoLoading = false;
    renderCrypto();
  }
}


// ---- Fuentes de precio cripto ----
const CRYPTO_SOURCES = ["coingecko", "binance", "coinbase", "kraken"];
const CRYPTO_SOURCE_TTL_MS = 5 * 60 * 1000;
const cryptoSourceCache = new Map();
let cryptoSelectedId = "bitcoin";
let cryptoSourcesLoading = false;
let cryptoSourcesSequence = 0;
let cryptoSourcesController = null;

function selectedCryptoCoin() {
  return CRYPTO_COINS.find((coin) => coin.id === cryptoSelectedId) || CRYPTO_COINS[0];
}

async function fetchCryptoSource(provider, coin, signal) {
  const options = { signal, credentials: "omit", cache: "no-store" };
  let price;
  if (provider === "binance") {
    if (coin.symbol === "USDT") return { na: true };
    const url = new URL("https://data-api.binance.vision/api/v3/ticker/price");
    url.searchParams.set("symbol", `${coin.symbol}USDT`);
    const response = await fetch(url, options);
    if (!response.ok) throw new Error(`Binance respondió con el código ${response.status}.`);
    price = Number((await response.json()).price);
  } else if (provider === "coinbase") {
    const response = await fetch(`https://api.coinbase.com/v2/prices/${coin.symbol}-USD/spot`, options);
    if (!response.ok) throw new Error(`Coinbase respondió con el código ${response.status}.`);
    price = Number((await response.json())?.data?.amount);
  } else if (provider === "kraken") {
    const url = new URL("https://api.kraken.com/0/public/Ticker");
    url.searchParams.set("pair", `${coin.symbol === "BTC" ? "XBT" : coin.symbol}USD`);
    const response = await fetch(url, options);
    if (!response.ok) throw new Error(`Kraken respondió con el código ${response.status}.`);
    const data = await response.json();
    if (data.error?.length) throw new Error(`Kraken: ${data.error[0]}`);
    price = Number(Object.values(data.result || {})[0]?.c?.[0]);
  } else {
    throw new Error(`Fuente desconocida: ${provider}`);
  }
  if (!Number.isFinite(price) || price <= 0) throw new Error(`${provider} no devolvió un precio válido.`);
  return { usd: price };
}

async function refreshCryptoSources(force = false) {
  const coin = selectedCryptoCoin();
  const now = Date.now();
  const providers = ["binance", "coinbase", "kraken"].filter((provider) => {
    const cached = cryptoSourceCache.get(`${provider}:${coin.symbol}`);
    return force || !cached || now - cached.fetchedAt >= CRYPTO_SOURCE_TTL_MS;
  });
  if (providers.length === 0) {
    renderCryptoSources();
    return;
  }
  if (cryptoSourcesController) cryptoSourcesController.abort();
  const sequence = ++cryptoSourcesSequence;
  const controller = new AbortController();
  cryptoSourcesController = controller;
  const timeoutId = window.setTimeout(() => controller.abort(), 8000);
  cryptoSourcesLoading = true;
  renderCrypto();
  try {
    await Promise.allSettled(providers.map(async (provider) => {
      let entry;
      try {
        entry = { ...(await fetchCryptoSource(provider, coin, controller.signal)), fetchedAt: Date.now() };
      } catch (error) {
        if (sequence !== cryptoSourcesSequence) return;
        console.error(`No se pudo consultar ${provider} para ${coin.symbol}:`, error);
        entry = { error: true, fetchedAt: Date.now() };
      }
      if (sequence !== cryptoSourcesSequence) return;
      cryptoSourceCache.set(`${provider}:${coin.symbol}`, entry);
      scheduleLiveCachePersist();
      renderCryptoSources();
    }));
  } finally {
    window.clearTimeout(timeoutId);
    if (sequence === cryptoSourcesSequence) {
      cryptoSourcesLoading = false;
      cryptoSourcesController = null;
      renderCrypto();
    }
  }
}

function renderCryptoSources() {
  const coin = selectedCryptoCoin();
  const fiat = cryptoFiat.value || "USD";
  const factor = usdToFiatFactor(fiat);
  const amount = parseAmount(cryptoAmount.value);
  const amountValid = cryptoAmount.value.trim() !== "" && Number.isFinite(amount) && amount >= 0;
  document.querySelector("#crypto-sources-coin").textContent = `${coin.name} · ${coin.symbol} → ${fiat}`;
  const links = {
    coingecko: `https://www.coingecko.com/en/coins/${coin.id}`,
    binance: `https://www.binance.com/en/trade/${coin.symbol}_USDT`,
    coinbase: "https://www.coinbase.com/price",
    kraken: "https://www.kraken.com/prices"
  };
  for (const provider of CRYPTO_SOURCES) {
    const card = document.querySelector(`#cs-${provider}`);
    const valueElement = document.querySelector(`#cs-${provider}-value`);
    const timeElement = document.querySelector(`#cs-${provider}-time`);
    card.href = links[provider];
    let entry;
    if (provider === "coingecko") {
      const price = cryptoPrices?.[coin.id];
      entry = price ? { usd: price.usd, fetchedAt: cryptoFetchedAt } : null;
    } else {
      entry = cryptoSourceCache.get(`${provider}:${coin.symbol}`) || null;
    }
    card.classList.toggle("is-stale", Boolean(entry?.error));
    if (entry?.na) {
      valueElement.textContent = "—";
      timeElement.textContent = translate("cryptoSourceNA");
    } else if (entry?.error) {
      valueElement.textContent = translate("quoteUnavailable");
      timeElement.textContent = translate("quoteUnavailable");
    } else if (!entry) {
      valueElement.textContent = "—";
      timeElement.textContent = cryptoLoading || cryptoSourcesLoading ? translate("quoteLoading") : "";
    } else if (factor === null) {
      valueElement.textContent = "—";
      timeElement.textContent = translate("cryptoWaitingRates");
    } else {
      const unit = entry.usd * factor;
      if (!amountValid) valueElement.textContent = translate("quoteInvalid");
      else if (cryptoInverted) valueElement.textContent = `${new Intl.NumberFormat(currentLanguage, { maximumSignificantDigits: 6 }).format(amount / unit)} ${coin.symbol}`;
      else valueElement.textContent = formatFiatPrice(amount * unit, fiat);
      timeElement.textContent = translate("cryptoSourceChecked", {
        time: new Intl.DateTimeFormat(currentLanguage, { hour: "2-digit", minute: "2-digit" }).format(new Date(entry.fetchedAt))
      });
    }
  }
}

function refreshAllCrypto() {
  void refreshCrypto(true);
  void refreshCryptoSources(true);
}

const tabsNav = document.querySelector("#tabs-nav");
function selectTab(tab, { persist = true } = {}) {
  if (!["calc", "fx", "crypto", "metals"].includes(tab)) tab = "calc";
  const crypto = tab === "crypto";
  currentTab = tab;
  lastDivisaTab = tab;
  calcOverlay.hidden = tab !== "calc";
  panelFx.hidden = tab !== "fx";
  panelCrypto.hidden = !crypto;
  panelMetals.hidden = tab !== "metals";
  appShell.dataset.section = tab;
  appShell.classList.toggle("is-calc", tab === "calc");
  if (sessionStarted) replayAnimation({ calc: calcOverlay, fx: panelFx, crypto: panelCrypto, metals: panelMetals }[tab], "fx-enter");
  if (persist) setPageScroll(0);
  if (tab === "fx" && persist && sessionStarted) {
    void refreshQuotes({ includeThirdParty: true });
    void refreshHistory();
  }
  for (const button of tabButtons) button.setAttribute("aria-selected", String(button.dataset.tab === tab));
  if (tab === "calc") {
    renderCalculator();
    calcExpressionElement.focus({ preventScroll: true });
  }
  if (tab === "metals") {
    renderMetals();
    void refreshMetals();
  }
  if (crypto) {
    if (!cryptoFiat.options.length) cryptoFiat.value = "";
    populateCryptoFiat();
    if (![...cryptoFiat.options].some((option) => option.value === cryptoFiat.value)) cryptoFiat.value = "USD";
    renderCrypto();
    void refreshCrypto();
    void refreshCryptoSources();
  }
  if (persist) void persistSessionState();
}

for (const button of tabButtons) button.addEventListener("click", () => selectTab(button.dataset.tab));
cryptoAmount.addEventListener("input", () => {
  renderCrypto();
  void persistSessionState();
});
cryptoFiat.addEventListener("change", () => {
  cryptoFiatPending = cryptoFiat.value;
  renderCrypto();
  void persistSessionState();
});
cryptoMode.addEventListener("click", () => {
  cryptoInverted = !cryptoInverted;
  renderCrypto();
  void persistSessionState();
});
cryptoRefreshButton.addEventListener("click", refreshAllCrypto);



// ---- Continuidad entre popup, ventana flotante y panel lateral ----
function applyTheme(theme) {
  setTheme(theme);
}

let userInteracted = false;
for (const eventName of ["wheel", "touchstart", "keydown", "pointerdown"]) {
  window.addEventListener(eventName, () => { userInteracted = true; }, { once: true, passive: true });
}

function restoreScroll(top) {
  const apply = () => {
    if (!userInteracted && Math.abs(getPageScroll() - top) > 4) setPageScroll(top);
  };
  window.setTimeout(apply, 400);
  window.setTimeout(apply, 1500);
}

// Lo que no cabe en restoreSessionState porque depende de piezas que se crean más tarde.
function restoreViewState(state) {
  if (!state || typeof state !== "object") return;
  const crypto = state.crypto;
  if (crypto && typeof crypto === "object") {
    if (typeof crypto.amount === "string" && crypto.amount.length <= 100) cryptoAmount.value = crypto.amount;
    if (typeof crypto.fiat === "string" && /^[A-Z]{3}$/.test(crypto.fiat)) cryptoFiatPending = crypto.fiat;
    cryptoInverted = crypto.inverted === true;
    if (CRYPTO_COINS.some((coin) => coin.id === crypto.selected)) cryptoSelectedId = crypto.selected;
  }
  if (Object.hasOwn(HISTORY_PERIODS, state.historyPeriod)) historyPeriod = state.historyPeriod;
  // Al abrir de cero siempre se empieza en Divisas; la pestaña solo se conserva al cambiar de vista
  // (popup, ventana flotante o panel), que ocurre al instante.
  const recent = Number.isFinite(state.savedAt) && Date.now() - state.savedAt < 6000;
  if (recent && ["calc", "fx", "crypto", "metals"].includes(state.tab)) selectTab(state.tab, { persist: false });
  const calc = state.calc;
  if (calc && typeof calc.expression === "string") {
    showRestoredCalculator(calc.expression.slice(0, 200), calc.fresh === true);
  }
  if (Number.isFinite(state.scroll) && state.scroll > 0) restoreScroll(state.scroll);
}

// Si hay otra vista abierta (por ejemplo el panel lateral y el popup), los cambios se reflejan en las dos.
function applyExternalState(state) {
  if (!state || typeof state !== "object" || state.source === viewId || !sessionStarted) return;
  let pairChanged = false;
  const hasOption = (select, value) => typeof value === "string" && [...select.options].some((option) => option.value === value);
  if (typeof state.amount === "string" && state.amount.length <= 100 && document.activeElement !== amountInput) {
    amountInput.value = state.amount;
  }
  if (hasOption(fromSelect, state.from) && fromSelect.value !== state.from) { fromSelect.value = state.from; pairChanged = true; }
  if (hasOption(toSelect, state.to) && toSelect.value !== state.to) { toSelect.value = state.to; pairChanged = true; }
  if (state.theme !== themeSelect.value) applyTheme(state.theme);
  if (Object.hasOwn(DIVISAGO_LOCALES, state.language) && state.language !== currentLanguage) setLanguage(state.language);
  const crypto = state.crypto;
  if (crypto && typeof crypto === "object") {
    if (typeof crypto.amount === "string" && crypto.amount.length <= 100 && document.activeElement !== cryptoAmount) cryptoAmount.value = crypto.amount;
    if (hasOption(cryptoFiat, crypto.fiat)) { cryptoFiat.value = crypto.fiat; cryptoFiatPending = crypto.fiat; }
    cryptoInverted = crypto.inverted === true;
    if (CRYPTO_COINS.some((coin) => coin.id === crypto.selected) && crypto.selected !== cryptoSelectedId) {
      cryptoSelectedId = crypto.selected;
      if (!panelCrypto.hidden) void refreshCryptoSources();
    }
  }
  let periodChanged = false;
  if (Object.hasOwn(HISTORY_PERIODS, state.historyPeriod) && state.historyPeriod !== historyPeriod) {
    historyPeriod = state.historyPeriod;
    periodChanged = true;
  }
  if (pairChanged) {
    updateCurrencyFlags();
    updateOptionSelection(fromOptions, fromSelect.value);
    updateOptionSelection(toOptions, toSelect.value);
    scheduleQuoteRefresh();
  } else if (periodChanged) {
    void refreshHistory();
  }
  updateConversion();
  renderQuotes();
  renderHistory();
  if (!panelCrypto.hidden) renderCrypto();
}

globalThis.chrome?.storage?.onChanged?.addListener((changes, area) => {
  if (area === "session" && changes[SESSION_STATE_STORAGE_KEY]) {
    applyExternalState(changes[SESSION_STATE_STORAGE_KEY].newValue);
  }
});

// El desplazamiento y lo que se acaba de cerrar también cuentan.
let scrollPersistTimeout = 0;
window.addEventListener("scroll", () => {
  window.clearTimeout(scrollPersistTimeout);
  scrollPersistTimeout = window.setTimeout(() => void persistSessionState(), 300);
}, { passive: true });
window.addEventListener("pagehide", () => void persistSessionState());
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "hidden") void persistSessionState();
});

// Gráficos y precios ya descargados: al cambiar de vista se ven al instante, sin volver a pedirlos.
let liveCacheTimeout = 0;
function scheduleLiveCachePersist() {
  window.clearTimeout(liveCacheTimeout);
  liveCacheTimeout = window.setTimeout(async () => {
    try {
      const history = [...historyCache].slice(-8).map(([key, value]) => [
        key,
        {
          at: value.at,
          provider: value.provider,
          noteKey: value.noteKey,
          noteSource: value.noteSource,
          points: value.points.map((point) => ({ date: point.date, rate: point.rate }))
        }
      ]);
      await getSessionStorageArea().set({
        [LIVE_CACHE_STORAGE_KEY]: { history, sources: [...cryptoSourceCache].slice(-24) }
      });
    } catch (error) {
      console.error("No se pudo guardar la caché de la sesión:", error);
    }
  }, 600);
}

function applyLiveCache(data) {
  if (!data || typeof data !== "object") return;
  const now = Date.now();
  for (const entry of Array.isArray(data.history) ? data.history : []) {
    const [key, value] = Array.isArray(entry) ? entry : [];
    if (
      typeof key !== "string" || !value || !Array.isArray(value.points) ||
      !Number.isFinite(value.at) || now - value.at >= HISTORY_CACHE_TTL_MS
    ) continue;
    const points = value.points
      .filter((point) => point && typeof point.date === "string" && Number.isFinite(point.rate) && point.rate > 0)
      .map((point) => ({ date: point.date, rate: point.rate }));
    if (points.length > 1) {
      historyCache.set(key, {
        points,
        at: value.at,
        provider: value.provider === "wise" ? "wise" : "frankfurter",
        noteKey: ["historyNoData", "historyFallback"].includes(value.noteKey) ? value.noteKey : "",
        noteSource: typeof value.noteSource === "string" ? value.noteSource.slice(0, 20) : ""
      });
    }
  }
  for (const entry of Array.isArray(data.sources) ? data.sources : []) {
    const [key, value] = Array.isArray(entry) ? entry : [];
    if (
      typeof key !== "string" || !/^(binance|coinbase|kraken):[A-Z]{2,6}$/.test(key) ||
      !value || !Number.isFinite(value.fetchedAt) || now - value.fetchedAt >= CRYPTO_SOURCE_TTL_MS
    ) continue;
    if (value.error === true) cryptoSourceCache.set(key, { error: true, fetchedAt: value.fetchedAt });
    else if (value.na === true) cryptoSourceCache.set(key, { na: true, fetchedAt: value.fetchedAt });
    else if (Number.isFinite(value.usd) && value.usd > 0) cryptoSourceCache.set(key, { usd: value.usd, fetchedAt: value.fetchedAt });
  }
}

// ---- Popup / ventana flotante / panel lateral ----
const viewMode = new URLSearchParams(location.search).get("mode"); // null = popup, "window" o "panel"
if (viewMode === "panel" || viewMode === "window" || viewMode === "desktop") document.documentElement.classList.add("is-panel");
const canFloat = Boolean(globalThis.chrome?.windows?.create && globalThis.chrome?.runtime?.getURL);
const canDock = Boolean(globalThis.chrome?.sidePanel?.open && globalThis.chrome?.windows?.getLastFocused);
const dockBackItem = document.querySelector("#dock-back");
const dockFloatItem = document.querySelector("#dock-float");
const dockSideItem = document.querySelector("#dock-side");
dockBackItem.hidden = !viewMode || viewMode === "desktop";
dockFloatItem.hidden = !canFloat || viewMode === "window";
dockSideItem.hidden = !canDock || viewMode === "panel";
if (dockBackItem.hidden && dockFloatItem.hidden && dockSideItem.hidden) document.querySelector("#dock").hidden = true;
// La ruta del panel lateral se prepara de antemano para que abrirlo siga ligado al clic del usuario.
if (canDock && viewMode !== "panel") {
  Promise.resolve(chrome.sidePanel.setOptions?.({ path: "sidepanel.html?mode=panel", enabled: true })).catch(() => {});
}

const pause = (ms) => new Promise((resolve) => window.setTimeout(resolve, ms));

async function findBrowserWindowId() {
  const windows = await chrome.windows.getAll({ windowTypes: ["normal"] });
  return (windows.find((item) => item.focused) || windows[0])?.id;
}

async function closeSidePanel() {
  const current = await chrome.windows.getCurrent();
  if (chrome.sidePanel.close) {
    await chrome.sidePanel.close({ windowId: current.id });
    return;
  }
  // Sin sidePanel.close(): desactivar y reactivar el panel lo cierra.
  await chrome.sidePanel.setOptions({ enabled: false });
  await pause(250);
  await chrome.sidePanel.setOptions({ path: "sidepanel.html?mode=panel", enabled: true });
}

async function closeCurrentView() {
  if (viewMode === "window") {
    const current = await chrome.windows.getCurrent();
    await chrome.windows.remove(current.id);
  } else if (viewMode === "panel") {
    await closeSidePanel();
  } else {
    window.close();
  }
}

// Antes de cambiar de vista se guarda todo, y la vista nueva lo recupera al abrirse.
async function switchView(target) {
  await persistSessionState();
  if (target === "popup") {
    // El popup se cierra si su ventana pierde el foco: se devuelve el foco a la ventana normal,
    // se abre el popup y solo entonces se cierra esta vista.
    try {
      const windowId = await findBrowserWindowId();
      if (windowId && viewMode === "window") await chrome.windows.update(windowId, { focused: true });
      await pause(150);
      await chrome.action?.openPopup?.(windowId ? { windowId } : undefined);
      await pause(400);
    } catch (error) {
      console.error("No se pudo abrir el popup:", error);
    }
    try {
      await closeCurrentView();
    } catch (error) {
      console.error("No se pudo cerrar la vista actual:", error);
    }
    return;
  }
  try {
    if (target === "window") {
      await chrome.windows.create({
        url: chrome.runtime.getURL("sidepanel.html?mode=window"),
        type: "popup",
        width: 390,
        height: 700
      });
    } else {
      const windowId = viewMode === "window" ? await findBrowserWindowId() : (await chrome.windows.getLastFocused()).id;
      await chrome.sidePanel.open({ windowId });
    }
  } catch (error) {
    console.error("No se pudo cambiar de vista:", error);
    return;
  }
  try {
    await closeCurrentView();
  } catch (error) {
    console.error("No se pudo cerrar la vista actual:", error);
  }
}

const desktopApi = globalThis.divisaDesktop;
if (viewMode === "desktop" && desktopApi) {
  // App de Windows: la chincheta mantiene la ventana siempre por encima de las demás.
  dockBackItem.hidden = true;
  dockSideItem.hidden = true;
  dockFloatItem.hidden = false;
  dockFloatItem.dataset.i18nTitle = "dockOnTop";
  dockFloatItem.dataset.i18nAriaLabel = "dockOnTop";
  document.querySelector("#dock").hidden = false;
  const showOnTop = (on) => {
    dockFloatItem.classList.toggle("is-active", on);
    dockFloatItem.setAttribute("aria-pressed", String(on));
  };
  dockFloatItem.addEventListener("click", async () => showOnTop(await desktopApi.toggleAlwaysOnTop()));
  desktopApi.isAlwaysOnTop().then(showOnTop).catch(() => {});
} else {
  dockBackItem.addEventListener("click", () => switchView("popup"));
  dockFloatItem.addEventListener("click", () => switchView("window"));
  dockSideItem.addEventListener("click", () => switchView("panel"));
}

// ---- Efectos: pequeñas recompensas visuales al pulsar, abrir y copiar ----
function replayAnimation(element, className) {
  if (!element) return;
  element.classList.remove(className);
  void element.offsetWidth;
  element.classList.add(className);
  element.addEventListener("animationend", () => element.classList.remove(className), { once: true });
}
const celebrate = (element) => replayAnimation(element, "fx-celebrate");
const popElement = (element) => replayAnimation(element, "fx-popped");

const RIPPLE_SELECTOR = [
  ".calc-keys button", ".tabs button", ".source-picker button", ".calc-margin-chip > button[data-margin]",
  ".unit-switch button", ".history-periods button", ".crypto-update", ".refresh-button", ".calc-actions button",
  ".faq-open", ".result-box", ".swap-button", ".currency-trigger", ".calc-open", ".backup-actions button",
  ".tutorial-next", ".tutorial-back", ".calc-copy-value", ".calc-gear", ".calc-reverse-toggle", ".dock-btn",
  ".auto-backup-list button", ".crypto-mode", ".calc-margin-add", ".language-dialog button", ".calc-swap"
].join(",");
const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");

function setupInteractionEffects() {
  // Onda que nace donde se pulsa.
  document.addEventListener("pointerdown", (event) => {
    if (event.button !== 0 || reducedMotion.matches) return;
    const target = event.target.closest?.(RIPPLE_SELECTOR);
    if (!target || target.disabled) return;
    const rect = target.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height) * 2;
    const ripple = document.createElement("span");
    ripple.className = "fx-ripple";
    ripple.style.cssText = `width:${size}px;height:${size}px;left:${event.clientX - rect.left - size / 2}px;top:${event.clientY - rect.top - size / 2}px`;
    if (getComputedStyle(target).position === "static") target.style.position = "relative";
    target.classList.add("fx-host");
    target.append(ripple);
    ripple.addEventListener("animationend", () => ripple.remove(), { once: true });
  }, { passive: true });

  // Las cifras importantes "aterrizan" cuando cambian.
  const observer = new MutationObserver((records) => {
    for (const record of records) {
      const element = record.target.nodeType === Node.TEXT_NODE ? record.target.parentElement : record.target;
      if (element && record.oldValue !== element.textContent) replayAnimation(element, "fx-tick");
    }
  });
  for (const element of [resultElement, calcToElement, calcFromElement, calcResultElement]) {
    observer.observe(element, { childList: true, characterData: true, subtree: true, characterDataOldValue: true });
  }

  // Los botones de intercambiar giran.
  swapButton.addEventListener("click", () => replayAnimation(swapButton, "fx-swapped"));
  document.querySelector("#calc-swap").addEventListener("click", (event) => replayAnimation(event.currentTarget, "fx-swapped"));
}
setupInteractionEffects();

applyTranslations();
loadPreferences();
