// Copias automáticas: una antes de cada actualización y otra al arrancar el navegador (una al día).
importScripts("backup.js");

// Restos de la antigua sección Fraseo: se borran solo si no contienen plantillas del usuario.
async function removeFraseoLeftovers() {
  const stored = await chrome.storage.local.get("phrases");
  if (Array.isArray(stored.phrases) && stored.phrases.length > 0) return;
  await chrome.storage.local.remove(["phrases", "usage", "preferences", "abbreviations", "shortcutNotice"]);
}

chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === "update") {
    await divisagoBackup.snapshot("update");
    await removeFraseoLeftovers();
  }
  else if (details.reason === "install") await divisagoBackup.restoreFromMirrorIfEmpty();
});

chrome.runtime.onStartup.addListener(() => divisagoBackup.snapshot("daily"));
