// Copias automáticas dentro del navegador (chrome.storage.local), compartidas por la app y el service worker.
// - Una copia al día (la primera vez que se abre algo ese día) y una antes de cada actualización.
// - Se conservan las últimas 7 y se descartan las más antiguas si ocupan demasiado.
// - Los ajustes pequeños se reflejan además en chrome.storage.sync: si Chrome tiene la sincronización
//   activada, sobreviven a reinstalar la extensión.
(() => {
  const BACKUP_KEY = "divisagoAutoBackups";
  const MIRROR_KEY = "divisagoSyncMirror";
  const MAX_BACKUPS = 7;
  const MAX_BYTES = 2_000_000;
  const MIRROR_KEYS = [
    "divisagoLanguage",
    "divisagoFavoriteCurrencies",
    "divisagoMargins",
    "divisagoRateSource",
    "divisagoTheme",
    "divisagoMetals",
    "divisagoAdDismissed",
    "divisagoTutorialDone"
  ];
  const DATA_KEYS = [...MIRROR_KEYS, "divisagoPremium"];

  function dayKey(date = new Date()) {
    const pad = (value) => String(value).padStart(2, "0");
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
  }

  async function readBackups() {
    const stored = await chrome.storage.local.get(BACKUP_KEY);
    return Array.isArray(stored[BACKUP_KEY]) ? stored[BACKUP_KEY] : [];
  }

  // reason: "daily" | "update" | "manual". Devuelve true si se ha guardado una copia nueva.
  async function snapshot(reason = "daily") {
    try {
      const [data, list] = await Promise.all([chrome.storage.local.get(DATA_KEYS), readBackups()]);
      const today = dayKey();
      if (reason !== "manual" && list.some((backup) => backup.day === today && backup.reason === reason)) return false;
      const payload = {};
      for (const key of DATA_KEYS) if (key in data) payload[key] = data[key];
      if (Object.keys(payload).length === 0) return false;
      const entry = { id: Date.now(), day: today, at: Date.now(), reason, data: payload };
      const kept = list.filter((backup) => reason === "manual" || !(backup.day === today && backup.reason === reason));
      let next = [entry, ...kept].slice(0, MAX_BACKUPS);
      while (next.length > 1 && JSON.stringify(next).length > MAX_BYTES) next = next.slice(0, -1);
      await chrome.storage.local.set({ [BACKUP_KEY]: next });
      const mirror = {};
      for (const key of MIRROR_KEYS) if (key in payload) mirror[key] = payload[key];
      await chrome.storage.sync.set({ [MIRROR_KEY]: mirror }).catch(() => {});
      return true;
    } catch (error) {
      console.error("No se pudo crear la copia automática:", error);
      return false;
    }
  }

  async function list() {
    try {
      return (await readBackups()).map(({ id, day, at, reason, data }) => ({
        id,
        day,
        at,
        reason,
        favorites: Array.isArray(data?.divisagoFavoriteCurrencies) ? data.divisagoFavoriteCurrencies.length : 0,
        margins: Array.isArray(data?.divisagoMargins) ? data.divisagoMargins.length : 0
      }));
    } catch (error) {
      console.error("No se pudieron leer las copias automáticas:", error);
      return [];
    }
  }

  async function restore(id) {
    const backup = (await readBackups()).find((item) => item.id === id);
    if (!backup?.data) return false;
    // Antes de pisar nada se guarda el estado actual por si hubo un error al elegir.
    await snapshot("manual");
    await chrome.storage.local.set(backup.data);
    return true;
  }

  // Si el almacenamiento local está vacío (por ejemplo, tras reinstalar) se recuperan los ajustes del espejo sincronizado.
  async function restoreFromMirrorIfEmpty() {
    try {
      const local = await chrome.storage.local.get(MIRROR_KEYS);
      if (Object.keys(local).length > 0) return false;
      const stored = await chrome.storage.sync.get(MIRROR_KEY);
      const mirror = stored[MIRROR_KEY];
      if (!mirror || typeof mirror !== "object" || Object.keys(mirror).length === 0) return false;
      await chrome.storage.local.set(mirror);
      return true;
    } catch (error) {
      console.error("No se pudo recuperar el espejo sincronizado:", error);
      return false;
    }
  }

  globalThis.divisagoBackup = { snapshot, list, restore, restoreFromMirrorIfEmpty };
})();
