// Configuración del banner. Sustituye los textos y enlaces por tus patrocinadores o enlaces de afiliado.
// No se puede cargar código externo de redes de anuncios (AdSense, etc.) en una extensión MV3.
// Los anuncios sin una URL https válida se ignoran.
const AD_ROTATION_MS = 30000;
const REMOVE_ADS_URL = ""; // URL de pago (Stripe/Lemon Squeezy/Gumroad). Vacío = oculta el botón.
// text y cta pueden ser un texto o un objeto por idioma ({ es, en, ... }); si falta el idioma se usa es y luego en.
const ADS = [
  {
    text: {
      es: "FullPage Saver, mi otra extensión.",
      en: "FullPage Saver, my other extension.",
      pt: "FullPage Saver, a minha outra extensão.",
      fr: "FullPage Saver, mon autre extension.",
      de: "FullPage Saver, meine andere Erweiterung.",
      it: "FullPage Saver, la mia altra estensione."
    },
    cta: { es: "Descubrir", en: "Discover", pt: "Descobrir", fr: "Découvrir", de: "Entdecken", it: "Scopri" },
    url: "https://chromewebstore.google.com/detail/igjphghlkmidddmnmlmdnhnepehpoena"
  }
  // { text: "Envía dinero con comisiones bajas", cta: "Probar", url: "https://tu-enlace-de-afiliado" }
];
